//
//  DetailViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "DetailViewController.h"
#import "AppDelegate.h"
#import "CommentsViewController.h"
#import "RatingViewController.h"

@interface DetailViewController ()


@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"DDDDD%@", self.instructorDetailsDictionary);
    [self getDetails];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    }
-(void)getDetails {
    // Prepare the URL that we'll get the country info data from.
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/instructor/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    NSLog(@"%@",url);
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        // Check if any data returned.
        if (data != nil) {
            // Convert the returned data into a dictionary.
            NSError *error;
            //            NSMutableDictionary *returnedDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                _instructorDetailsDictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                [self.tableView reloadData];
                
                NSLog(@"IDD%@", _instructorDetailsDictionary);
                NSLog(@"GGGG%@", self.instructorDetailsDictionary);
            }
        }
    }];
    
}

- (UIImage *)imageForRating:(int)rating
{
    switch (rating) {
        case 1: return [UIImage imageNamed:@"1StarSmall"];
        case 2: return [UIImage imageNamed:@"2StarsSmall"];
        case 3: return [UIImage imageNamed:@"3StarsSmall"];
        case 4: return [UIImage imageNamed:@"4StarsSmall"];
        case 5: return [UIImage imageNamed:@"5StarsSmall"];
    }
    return nil;
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 7;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailsCell" forIndexPath:indexPath];

//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailsCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"DetailsCell"];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellStyleValue2;
//        UITableViewCellStyleValue2
        
    }
    UILabel *titleLabel = (UILabel *)[cell viewWithTag:100];
    UILabel *detailLabel = (UILabel *)[cell viewWithTag:101];
    UIImageView *ratingImageView = (UIImageView *)[cell viewWithTag:102];
    switch (indexPath.row) {
        case 0:
            titleLabel.text = @"First Name: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"firstName"];
            break;
        case 1:
            titleLabel.text = @"Last Name: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"lastName"];
            break;
        case 2:
            titleLabel.text = @"Office: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"office"];
            break;
        case 3:
            titleLabel.text = @"Phone: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"phone"];
            break;
        case 4:
            titleLabel.text = @"Email: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"email"];
            break;
        case 5:
            titleLabel.text = @"Rating";
            detailLabel.text = @"";
            ratingImageView.image = [self imageForRating:3];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleDefault;

            break;
        case 6:
            titleLabel.text = @"Comments";
            detailLabel.text = @"";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleDefault;
            break;
            
        default:
            break;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 5) {
        [self performSegueWithIdentifier:@"idSegueRatings" sender:self];
    }
    if (indexPath.row == 6) {
        [self performSegueWithIdentifier:@"idSegueComments" sender:self];
    }
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"idSegueRatings"]) {
        RatingViewController *ratingViewController = [segue destinationViewController];
        ratingViewController.instructor_id = self.instructor_id;
    }
    
    if ([segue.identifier isEqualToString:@"idSegueComments"]) {
        CommentsViewController *commentsViewController = [segue destinationViewController];
        commentsViewController.instructor_id = self.instructor_id;
    }
    
    
}


@end
