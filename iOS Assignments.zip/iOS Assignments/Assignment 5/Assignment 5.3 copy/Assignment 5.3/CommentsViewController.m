//
//  CommentsViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "CommentsViewController.h"
#import "AppDelegate.h"

@interface CommentsViewController () {
    //    NSString *instructor_id;
    
    NSMutableArray *dataArray;
    NSMutableArray *commentsArray;
    NSMutableArray *dateArray;
}

//@property(nonatomic,strong) AddCommentsViewController *addController;

@end

@implementation CommentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Comments";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addComments)];
    [self getComments];
    
}

- (void)viewWillAppear:(BOOL)animated

{
    [self.tableView reloadData];
    [self getComments];
}

-(void) addComments
{
    [self performSegueWithIdentifier:@"idSegueAddComments" sender:self];
    
    //    _addController = [[AddCommentsViewController alloc] init];
    //    _addController.delegate = self;
    //
    //    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:_addController];
    //   [self performSegueWithIdentifier:@"idSegueAddComments" sender:self];
    //    [self presentViewController:navController animated:YES completion:nil];
    //    [self performSegueWithIdentifier:@"idSegueAddComments" sender:self];
}

//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
//{
//    if ([[segue identifier] isEqualToString:@"idSegueAddComments"]) {
//        AddCommentsViewController *addCommentsVC = segue.destinationViewController;
//        addCommentsVC.delegate = self;
//    }
//}

-(void) addCommentText:(NSString *)commentText {
    
    
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comments/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    NSLog(@"%@",url);
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:60.0];
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [request setHTTPMethod:@"POST"];
    
    ////////////
    NSMutableDictionary *mutDict = [[NSMutableDictionary alloc] init];
    [mutDict setObject:commentText forKey:@"text"];
    [mutDict setObject:@"101" forKey:@"id"];
    [mutDict setObject:[NSDate date] forKey:@"date"];
    NSLog(@"%@", mutDict);
    NSError * error;
    NSData * data = [NSJSONSerialization dataWithJSONObject:mutDict
                                                    options:NSJSONWritingPrettyPrinted error:&error];
//    NSString * jsonString = [[NSString alloc] initWithData:data
//                                                  encoding:NSUTF8StringEncoding];
    ////////////
//    NSDictionary *mapData = [[NSDictionary alloc] initWithObjectsAndKeys: @"TEST IOS", @"name",
//                             @"IOS TYPE", @"typemap",
//                             nil];
//    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
//    [request setHTTPBody:postData];
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
    }];
    
    [postDataTask resume];
    
    
    
    
//    [commentsArray addObject:mutDict];
    [self.tableView reloadData];
    
}


-(void)getComments{
    // Prepare the URL that we'll get the country info data from.
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comments/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    NSLog(@"%@",url);
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        // Check if any data returned.
        if (data != nil) {
            // Convert the returned data into a dictionary.
            NSError *error;
            NSLog(@"%@", data);
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                dataArray = [NSJSONSerialization JSONObjectWithData:data
                                                                  options:NSJSONReadingMutableContainers
                                                                    error:nil];
                NSLog(@"dataArray%@", dataArray);
                commentsArray = [[NSMutableArray alloc] init];
                dateArray = [[NSMutableArray alloc] init];
                
                for(int i=0; i<[dataArray count]; i++) {
                    NSString *comments = [dataArray[i] valueForKey:@"text"];
                    if ([comments  isEqual: @""]) {
                        NSLog(@"Empty");
                        continue;
                    }
                    [commentsArray addObject:comments];
                    NSLog(@"Comments: %@", commentsArray);
                    NSString *date = [dataArray[i] valueForKey:@"date"];
                    [dateArray addObject:date];
                }
                
                [self.tableView reloadData];
                
                NSLog(@"Array %@",commentsArray);
                NSLog(@"Array %@",dateArray);
            }
        }
    }];
    NSLog(@"ABC");
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [dateArray count];
//    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentsCell" forIndexPath:indexPath];
    
    cell.textLabel.text = [commentsArray objectAtIndex:indexPath.row];
    cell.detailTextLabel.text = [dateArray objectAtIndex:indexPath.row];
    NSLog(@"Text label%@", [commentsArray objectAtIndex:indexPath.row]);
    return cell;
}


@end
