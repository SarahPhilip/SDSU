//
//  AddCommentsViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol AddCommentsDelegate <NSObject>

-(void) addCommentText:(NSString *)comment;

@end

@interface AddCommentsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *comments;
@property (unsafe_unretained) id <AddCommentsDelegate> delegate;
- (void)saveAction;
- (void) cancelAction;

@end
