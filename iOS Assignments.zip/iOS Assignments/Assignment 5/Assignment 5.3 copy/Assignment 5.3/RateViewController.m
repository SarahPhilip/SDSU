//
//  RateViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "RateViewController.h"

@interface RateViewController ()

@property (strong) NSArray *ratingLabels;

@end

@implementation RateViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _ratingLabels = [NSArray arrayWithObjects:@"Unrated", @"Hate it", @"Don't like it", @"It's OK", @"It's good", @"It's great", nil];
    
    _StarRatingControl.delegate = self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)starRatingControl:(StarRatingControl *)control didUpdateRating:(NSUInteger)rating {
    _ratingLabel.text = [_ratingLabels objectAtIndex:rating];
}

- (void)starRatingControl:(StarRatingControl *)control willUpdateRating:(NSUInteger)rating {
    _ratingLabel.text = [_ratingLabels objectAtIndex:rating];
}

@end
