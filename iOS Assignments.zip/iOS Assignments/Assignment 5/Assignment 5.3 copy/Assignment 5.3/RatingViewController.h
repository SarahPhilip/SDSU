//
//  RatingViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RatingViewController : UITableViewController

@property (nonatomic, strong) NSString *instructor_id;

@end
