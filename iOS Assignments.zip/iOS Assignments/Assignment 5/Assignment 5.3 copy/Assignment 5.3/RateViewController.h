//
//  RateViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RateViewController : UIViewController <StarRatingDelegate>

@property (weak) IBOutlet UILabel *ratingLabel;
@property (weak) IBOutlet StarRatingControl *starRatingControl;

@end

