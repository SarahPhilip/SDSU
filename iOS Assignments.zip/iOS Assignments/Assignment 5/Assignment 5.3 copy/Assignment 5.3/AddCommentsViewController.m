//
//  AddCommentsViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AddCommentsViewController.h"

@interface AddCommentsViewController ()

@end

@implementation AddCommentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Add Comment";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelAction)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveAction)];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)saveAction {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if(![self.comments.text isEqualToString:@""]){
        
        
    }
    
    /////------------///////////
//    
//    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comment/10"];
//    NSURL *url = [NSURL URLWithString:URLString];
//    NSLog(@"%@",url);
//    
//    ////////////
//    NSMutableDictionary *mutDict = [[NSMutableDictionary alloc] init];
//    [mutDict setObject:_comments.text forKey:@"text"];
//    [mutDict setObject:@"101" forKey:@"id"];
//        NSDate *date = [[NSDate alloc]init];
//        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//        [formatter setDateFormat:@"MM/dd/yyyy"];
//        NSString *stringFromDate = [formatter stringFromDate:date];
//        NSLog(@"%@", stringFromDate);
//        [mutDict setObject:stringFromDate forKey:@"date"];
//    NSError * error;
//    NSData * data = [NSJSONSerialization dataWithJSONObject:mutDict
//                                                    options:NSJSONWritingPrettyPrinted error:&error];
//    //    NSString * jsonString = [[NSString alloc] initWithData:data
//    //                                                  encoding:NSUTF8StringEncoding];
//    ////////////
//    //    NSDictionary *mapData = [[NSDictionary alloc] initWithObjectsAndKeys: @"TEST IOS", @"name",
//    //                             @"IOS TYPE", @"typemap",
//    //                             nil];
//    //    NSData *postData = [NSJSONSerialization dataWithJSONObject:mapData options:0 error:&error];
//    //    [request setHTTPBody:postData];
//    
//    
//    
//    
//    // Create a POST request with our JSON as a request body.
//    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
//    request.HTTPMethod = @"POST";
//    request.HTTPBody = data;
//    
//    // Create a task.
//    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request
//                                                                 completionHandler:^(NSData *data,
//                                                                                     NSURLResponse *response,
//                                                                                     NSError *error)
//                                  {
//                                      if (!error)
//                                      {
//                                          NSLog(@"Status code: %i", ((NSHTTPURLResponse *)response).statusCode);
//                                      }
//                                      else
//                                      {
//                                          NSLog(@"Error: %@", error.localizedDescription);
//                                      }
//                                  }];
//    
//    // Start the task.
//    [task resume];
//    
//    
//    
//    
//    //    [commentsArray addObject:mutDict];
////    [self.tableView reloadData];
//    
    ///////--------//////////////
        /////////
        
    //build an info object and convert to json
    NSMutableDictionary *mutDict = [[NSMutableDictionary alloc] init];
    [mutDict setObject:_comments.text forKey:@"text"];
//    [mutDict setObject:@"101" forKey:@"id"];
//    
//    NSDate *date = [[NSDate alloc]init];
//    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//    [formatter setDateFormat:@"MM/dd/yyyy"];
//    NSString *stringFromDate = [formatter stringFromDate:date];
//    NSLog(@"%@", stringFromDate);
//    [mutDict setObject:stringFromDate forKey:@"date"];
    NSLog(@"MultDict%@", mutDict);
    NSError *error;
    //convert object to data
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:mutDict options:kNilOptions error:&error];
    NSLog(@"%@", jsonData);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comment/10"];
    NSURL *url = [NSURL URLWithString:URLString];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
//    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"text/plain" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[_comments.text dataUsingEncoding:NSUTF8StringEncoding]];
    
    // print json:
    NSLog(@"JSON summary: %@", [[NSString alloc] initWithData:jsonData
                                                     encoding:NSUTF8StringEncoding]);
    

    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [connection start];
    
    if(connection)
    
        NSLog(@"Connection");
    else
        NSLog(@"No Connection");
//    CommentsViewController *commentsVC;
////    [commentsVC getComments];
//    [commentsVC.tableView reloadData];
    
        ////////
//        NSLog(@"%@", self.delegate);
//    {
//        if([self.delegate respondsToSelector:@selector(addCommentText:)])
//        {
//            [self.delegate addCommentText:self.comments.text];
//        }
//    }
        }

- (void)cancelAction{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
