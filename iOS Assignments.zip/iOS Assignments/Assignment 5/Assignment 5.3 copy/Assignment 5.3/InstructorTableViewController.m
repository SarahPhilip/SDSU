//
//  InstructorTableViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/7/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "InstructorTableViewController.h"
#import "DetailViewController.h"
#import "AppDelegate.h"

@interface InstructorTableViewController () {
//    NSString *instructor_id;
    
    NSArray *instructorArray;
    
    NSMutableArray *nameArray;
//    NSMutableDictionary * instructorDetailsDictionary;
}

-(void)getInstructor;
//-(void)getDetails:(NSString *) instructor_id;

@end

@implementation InstructorTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getInstructor];
//    NSURLRequest *theRequest=[NSURLRequest
//                              requestWithURL:[NSURL URLWithString: @"http://bismarck.sdsu.edu/rateme/list"]
//                              cachePolicy:NSURLRequestUseProtocolCachePolicy
//                              timeoutInterval:60.0];
//    NSURLConnection *theConnection=[[NSURLConnection alloc]
//                                    initWithRequest:theRequest delegate:self];
//    if (theConnection) {
//        receivedData = [NSMutableData data];
//    } else {
//        NSLog(@"Connection Failed");
//    }
//    NSURL *myURL = [NSURL URLWithString:@"http://bismarck.sdsu.edu/rateme/list"];
//    
//    NSURLRequest *myRequest = [NSURLRequest requestWithURL:myURL];
//    
//    NSURLConnection *myConnection = [NSURLConnection connectionWithRequest:myRequest delegate:self];
//    
//     self.clearsSelectionOnViewWillAppear = NO;
    
}

-(void)getInstructor{
    // Prepare the URL that we'll get the country info data from.
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/list"];
    NSURL *url = [NSURL URLWithString:URLString];
    NSLog(@"%@",url);
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        // Check if any data returned.
        if (data != nil) {
            // Convert the returned data into a dictionary.
            NSError *error;
            NSLog(@"%@", data);
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                instructorArray = [NSJSONSerialization JSONObjectWithData:data
                                                                options:NSJSONReadingMutableContainers
                                                                    error:nil];
                NSLog(@"Instructor Array%@", instructorArray);
                nameArray = [[NSMutableArray alloc] init];
                
                for(int i=0; i<[instructorArray count]-1; i++) {
                    NSString *firstName = [instructorArray[i] valueForKey:@"firstName"];
                    NSString *firstName_space = [firstName stringByAppendingString:@" "];
                    NSString *lastName = [instructorArray[i] valueForKey:@"lastName"];
                    NSString *fullName = [firstName_space stringByAppendingString:lastName];
                    [nameArray addObject:fullName];
                }
                
                [self.tableView reloadData];

                NSLog(@"Array %@",instructorArray);
            }
        }
    }];
    
}

//- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
//{
//    [receivedData appendData:data];
//}
//
//- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
//{
//    NSLog(@"Connection failed! Error - %@ %@",
//          [error localizedDescription],
//          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
//}
//
//- (void)connectionDidFinishLoading:(NSURLConnection *)connection
//{
//    
//    // Hide activity indicator
//        instructorArray = [NSJSONSerialization JSONObjectWithData:data
//                                                         options:NSJSONReadingMutableContainers
//                                                           error:nil];
//        nameArray = [[NSMutableArray alloc] init];
//    
//        for(int i=0; i<[instructorArray count]-1; i++) {
//            NSString *firstName = [instructorArray[i] valueForKey:@"firstName"];
//            NSString *firstName_space = [firstName stringByAppendingString:@" "];
//            NSString *lastName = [instructorArray[i] valueForKey:@"lastName"];
//            NSString *fullName = [firstName_space stringByAppendingString:lastName];
//            [nameArray addObject:fullName];
//        }
//    
//        [self.tableView reloadData];
//    
//}

//- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
//    
//    
//    
//    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*) response;
//    
//    int errorCode = httpResponse.statusCode;
//    
//    NSString *fileMIMEType = [[httpResponse MIMEType] lowercaseString];
//    
//    NSLog(@"response is %d, %@", errorCode, fileMIMEType);
//    
//}
//
//- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
//    
//    instructorArray = [NSJSONSerialization JSONObjectWithData:data
//                                                     options:NSJSONReadingMutableContainers
//                                                       error:nil];
//
//    
//}
//
//- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
//    
//    // inform the user
//    
//    NSLog(@"Connection failed! Error - %@ %@",
//          
//          [error localizedDescription],
//          
//          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
//    
//}
//
//- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
//    
//    // do something with the data
//    
//    nameArray = [[NSMutableArray alloc] init];
//    
//    for(int i=0; i<[instructorArray count]-1; i++) {
//        NSString *firstName = [instructorArray[i] valueForKey:@"firstName"];
//        NSString *firstName_space = [firstName stringByAppendingString:@" "];
//        NSString *lastName = [instructorArray[i] valueForKey:@"lastName"];
//        NSString *fullName = [firstName_space stringByAppendingString:lastName];
//        [nameArray addObject:fullName];
//    }
//    
//    [self.tableView reloadData];
//   
//}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [nameArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"instructorCell" forIndexPath:indexPath];
    
    cell.textLabel.text = [nameArray objectAtIndex:indexPath.row];
    return cell;
}





#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
//    NSLog(@"%@", indexPath);
    DetailViewController *detailVC = segue.destinationViewController;
    
        NSString *instructor = self->nameArray[indexPath.row];
    NSString *instructor_id = [instructorArray[indexPath.row]valueForKey:@"id"];
    detailVC.instructor_id = instructor_id;
    NSLog(@"HHH%@", instructor_id);
//    NSLog(@"INST%@", instructor);
    
//    [self getDetails:instructor_id];
//    detailVC.instructorDetailsDictionary = self.instructorDetailsDictionary;

        detailVC.navigationItem.title = instructor;

    
}



@end
