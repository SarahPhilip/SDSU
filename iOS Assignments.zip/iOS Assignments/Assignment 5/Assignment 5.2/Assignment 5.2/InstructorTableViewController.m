//
//  InstructorTableViewController.m
//  Assignment 5.2
//
//  Created by Shameetha Sara Jacob on 11/7/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "InstructorTableViewController.h"

@interface InstructorTableViewController () {
    NSDictionary *instructorDictionary;
    NSMutableArray *instructorArray;
    id object;
}

@end

@implementation InstructorTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *myURL = [NSURL URLWithString:@"http://bismarck.sdsu.edu/rateme/list"];
    
    
    
    NSURLRequest *myRequest = [NSURLRequest requestWithURL:myURL];
    
    NSURLConnection *myConnection = [NSURLConnection connectionWithRequest:myRequest delegate:self];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    
    
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*) response;
    
    int errorCode = httpResponse.statusCode;
    
    NSString *fileMIMEType = [[httpResponse MIMEType] lowercaseString];
    
    NSLog(@"response is %d, %@", errorCode, fileMIMEType);
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    NSLog(@"data is %@", data);
    
    NSString *myString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"string is %@", myString);
    
    NSError *error = nil;
    
    object = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    
    // Verify object retrieved is dictionary
//    if ([object isKindOfClass:[NSArray class]] && error == nil)
//    {
//        NSLog(@"dictionary: %@", object);
//        NSLog(@"Is an Array");
//        NSLog(@"%@",[object valueForKey:@"firstName"]);
//        NSArray *array2 = [array1 valueForKey:@"name"];
        // Get the value (string) for key 'next_page'
//        NSString *str;
//        str = [object objectForKey:@"firstName"];
//        NSLog(@"first_name: %@", str);
        
        // Get the value (an array) for key 'results'
//        NSArray *array;
//        // Get the 'results' array
//        if ([[object objectForKey:@"results"] isKindOfClass:[NSArray class]])
//        {
//            array = [object objectForKey:@"results"];
//            NSLog(@"results array: %@", array);
//        }
    }
//    else
//        NSLog(@"Not dictionary");
//}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
    
    
    // inform the user
    
    NSLog(@"Connection failed! Error - %@ %@",
          
          [error localizedDescription],
          
          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    // do something with the data
    
    // receivedData is declared as a method instance elsewhere
    instructorArray = [[NSMutableArray alloc] init];
    NSLog(@"First Name%@", [object[0] valueForKey:@"firstName"]);
    for(int i=0; i<[object count]; i++) {
        NSLog(@"FN%@", [object[i] valueForKey:@"firstName"]);
        NSString *temp = [object[i] valueForKey:@"firstName"];
        [instructorArray addObject:temp];
        //        NSLog(@"New Array%@", instructorArray);
        
    }
    NSLog(@"New Array%@", instructorArray);

    
//    instructorArray = [[NSMutableArray alloc] initWithCapacity:18];
//    for (id name in object )
//        {
////          [instructorArray addObject:[object[name] valueForKey:@"firstName"]];
//            NSLog(@"%@", [object[name] valueForKey:@"firstName"]);
//           NSLog(@"instructorArray %@", instructorArray);
//
//        }
//        NSLog(@"instructorArray %@", instructorArray);
    
    

//    for (NSString *key in instructorDictionary) {
    
//        NSLog(@"the key is %@", instructorDictionary[key]);
        
//        id object = instructorDictionary[key]; // this will be apikey,format,method etc...
//        NSLog(@"%@",object);
        
//        if ([object isKindOfClass:[NSDictionary class]]) { //first 4 are arrays-crsh-dicts
//            
//            NSLog(@"object valueForKey is %@", [object valueForKey:@"firstName"]);
//            
//            [instructorArray addObject:[object valueForKey:@"firstName"]];
//            
//            
//            
//        } else {
//            
//            [instructorArray addObject:instructorDictionary[key]];
//            
//        }
        
//    }
    
//    NSLog(@"instructorArray %@", instructorArray);
    
    [self.tableView reloadData];

 NSLog(@"Succeeded!");

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier" forIndexPath:indexPath];
    
     cell.textLabel.text = [instructorArray objectAtIndex:indexPath.row];
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
