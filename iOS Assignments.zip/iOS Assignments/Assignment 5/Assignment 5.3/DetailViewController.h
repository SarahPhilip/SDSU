//
//  DetailViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DetailViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate> {
    NSString *rating;
    NSString *comments;
}

@property (nonatomic) NSDictionary *instructorDetailsDictionary;
@property (copy, nonatomic) NSString *instructor_id;

-(void)getDetails;

@end
