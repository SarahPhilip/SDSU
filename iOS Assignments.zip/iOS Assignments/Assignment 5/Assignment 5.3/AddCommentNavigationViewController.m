//
//  AddCommentNavigationViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AddCommentNavigationViewController.h"

@interface AddCommentNavigationViewController ()

@end

@implementation AddCommentNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"NVCID%@", self.instructor_id);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    AddCommentsViewController *addCVC = segue.destinationViewController;
    addCVC.instructor_id = self.instructor_id;
}


@end
