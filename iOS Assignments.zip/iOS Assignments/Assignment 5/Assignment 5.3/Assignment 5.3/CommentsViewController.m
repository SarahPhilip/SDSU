//
//  CommentsViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "CommentsViewController.h"
#import "AppDelegate.h"

@interface CommentsViewController ()
@end

@implementation CommentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Comments";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addComments)];
    self.tableView.estimatedRowHeight = 68.0;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self getComments];
    
}

- (void)viewWillAppear:(BOOL)animated

{
    [self.tableView reloadData];
    [self getComments];
}

-(void) addComments
{
    [self performSegueWithIdentifier:@"idSegueAddComments" sender:self];
    
}


-(void)getComments{
    // Prepare the URL that we'll get the country info data from.
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comments/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        // Check if any data returned.
        if (data != nil) {
            // Convert the returned data into a dictionary.
            NSError *error;
            NSLog(@"%@", data);
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                _dataArray = [NSJSONSerialization JSONObjectWithData:data
                                                                  options:NSJSONReadingMutableContainers
                                                                    error:nil];
                _commentsArray = [[NSMutableArray alloc] init];
                _dateArray = [[NSMutableArray alloc] init];
                _idArray = [[NSMutableArray alloc]init];
                for(int i=0; i<[_dataArray count]; i++) {
                    NSString *comments = [_dataArray[i] valueForKey:@"text"];
                    if ([comments  isEqual: @""]) {
                        NSLog(@"Empty");
                        continue;
                    }
                    [_commentsArray addObject:comments];
                    NSLog(@"Comments: %@", _commentsArray);
                    NSString *date = [_dataArray[i] valueForKey:@"date"];
                    [_dateArray addObject:date];
                    NSString *id = [_dataArray[i] valueForKey:@"id"];
                    [_idArray addObject:id];
                }
                [self.tableView reloadData];
                _comment_count = [_dateArray count];
            }
        }
    }];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [_dateArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentsCell" forIndexPath:indexPath];
    
    UILabel *idLabel = (UILabel *)[cell viewWithTag:1];
    UILabel *dateLabel = (UILabel *)[cell viewWithTag:2];
    UILabel *commentLabel = (UILabel *)[cell viewWithTag:3];
    cell.selectionStyle = UITableViewCellEditingStyleNone;
    commentLabel.text = [_commentsArray objectAtIndex:indexPath.row];
    dateLabel.text = [_dateArray objectAtIndex:indexPath.row];
    idLabel.text = [NSString stringWithFormat:@"%@",[_idArray objectAtIndex:indexPath.row]];
    return cell;
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
//    if ([segue.identifier isEqualToString:@"idSegueAddComments"]) {
//        AddCommentsViewController *addCVC = segue.destinationViewController;
//        addCVC.instructor_id = self.instructor_id;

//    }
    
    AddCommentsViewController* controller =
    (AddCommentsViewController*)[[segue destinationViewController] topViewController];
//    [controller setDataFromA:self.instructor_id];
    [controller setInstructor_id:self.instructor_id];
}

@end
