//
//  AddCommentsViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddCommentsViewController : UIViewController
<UITextViewDelegate>

@property (nonatomic, strong) NSString *instructor_id;
@property (weak, nonatomic) IBOutlet UITextView *comments;

@end
