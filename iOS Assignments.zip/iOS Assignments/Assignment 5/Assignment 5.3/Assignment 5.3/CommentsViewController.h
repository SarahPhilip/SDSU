//
//  CommentsViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddCommentsViewController.h"

@interface CommentsViewController : UITableViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSString *instructor_id;
@property (nonatomic, assign) NSInteger comment_count;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *commentsArray;
@property (nonatomic, strong) NSMutableArray *dateArray;
@property (nonatomic, strong) NSMutableArray *idArray;
-(void)getComments;

@end
