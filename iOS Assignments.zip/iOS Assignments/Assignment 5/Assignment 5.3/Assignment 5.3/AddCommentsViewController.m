//
//  AddCommentsViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AddCommentsViewController.h"

@interface AddCommentsViewController ()

@end

@implementation AddCommentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Add Comment";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelAction)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveAction)];
    [self.comments becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)saveAction {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.comments resignFirstResponder];
    
    if(![self.comments.text isEqualToString:@""]){
   
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/comment/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[_comments.text dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [connection start];
    
    if(connection)
    
        NSLog(@"Connection");
    else
        NSLog(@"No Connection");
    }
}

- (void)cancelAction{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    NSUInteger lengthy = textView.text.length - range.length + text.length;
    NSLog(@"%lu",(unsigned long)lengthy);
    if (lengthy > 0) {
        self.navigationItem.rightBarButtonItem.enabled = YES;
    } else {
        self.navigationItem.rightBarButtonItem.enabled = NO;
    }
    return YES;
}
//- (void)textViewDidChange:(UITextView *)textView
//{
//    //Access the textView Content
//    //From here you can get the last text entered by the user
//    NSArray *stringsSeparatedBySpace = [textView.text componentsSeparatedByString:@" "];
//    //then you can check whether its one of your userstrings and trigger the event
//    NSString *lastString = [stringsSeparatedBySpace lastObject];
//    if([lastString isEqualsToString:@"http://www.stackoverflow.com"]) //add more conditions here
//    {
//        [self callActionMethod];
//    }
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
