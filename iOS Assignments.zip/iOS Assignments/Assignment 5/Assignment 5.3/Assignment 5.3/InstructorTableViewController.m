//
//  InstructorTableViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/7/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "InstructorTableViewController.h"
#import "DetailViewController.h"
#import "AppDelegate.h"

@interface InstructorTableViewController ()
//
//    NSArray *instructorArray;
//    NSMutableArray *nameArray;
//}

@end

@implementation InstructorTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getInstructor];
}

-(void)getInstructor{
   
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/list"];
    NSURL *url = [NSURL URLWithString:URLString];
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        // Check if any data returned.
        if (data != nil) {
            // Convert the returned data into a dictionary.
            NSError *error;
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                _instructorArray = [NSJSONSerialization JSONObjectWithData:data
                                                                options:NSJSONReadingMutableContainers
                                                                    error:nil];
                _nameArray = [[NSMutableArray alloc] init];
                for(int i=0; i<[_instructorArray count]; i++) {
                    NSString *name = [_instructorArray[i] valueForKey:@"firstName"];
                    name = [name stringByAppendingString:@" "];
                    name = [name stringByAppendingString:[_instructorArray[i] valueForKey:@"lastName"]];
                    [_nameArray addObject:name];
                }
                [self.tableView reloadData];
            }
        }
    }];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [_nameArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"instructorCell" forIndexPath:indexPath];
    cell.textLabel.text = [_nameArray objectAtIndex:indexPath.row];
    return cell;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    DetailViewController *detailVC = segue.destinationViewController;
    NSString *instructor = self.nameArray[indexPath.row];
    NSString *instructor_id = [_instructorArray[indexPath.row]valueForKey:@"id"];
    detailVC.instructor_id = instructor_id;
    detailVC.navigationItem.title = instructor;
}

@end
