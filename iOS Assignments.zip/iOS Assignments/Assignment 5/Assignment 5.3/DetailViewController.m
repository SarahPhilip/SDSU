//
//  DetailViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "DetailViewController.h"
#import "AppDelegate.h"
#import "CommentsViewController.h"
#import "RateViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getDetails];
    }

- (void)viewWillAppear:(BOOL)animated

{
    [self.tableView reloadData];
    [self getDetails];
}

-(void)getDetails {
    
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/instructor/%@", self.instructor_id];
    NSURL *url = [NSURL URLWithString:URLString];
    [AppDelegate downloadDataFromURL:url withCompletionHandler:^(NSData *data) {
        if (data != nil) {
            NSError *error;            
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
            else{
                self.instructorDetailsDictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                [self.tableView reloadData];
                rating = [NSString stringWithFormat:@"%@ / 5 (%@ ratings)",self.instructorDetailsDictionary[@"rating"][@"average"], self.instructorDetailsDictionary[@"rating"][@"totalRatings"]];
            }
        }
    }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 7;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailsCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"DetailsCell"];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellEditingStyleNone;
    }
    UILabel *titleLabel = (UILabel *)[cell viewWithTag:100];
    UILabel *detailLabel = (UILabel *)[cell viewWithTag:101];
    
    switch (indexPath.row) {
        case 0:
            titleLabel.text = @"First Name: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"firstName"];
            break;
        case 1:
            titleLabel.text = @"Last Name: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"lastName"];
            break;
        case 2:
            titleLabel.text = @"Office: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"office"];
            break;
        case 3:
            titleLabel.text = @"Phone: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"phone"];
            break;
        case 4:
            titleLabel.text = @"Email: ";
            detailLabel.text = [self.instructorDetailsDictionary objectForKey:@"email"];
            break;
        case 5:
            titleLabel.text = @"Rating";
            detailLabel.text = rating;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleDefault;
            break;
        case 6:
            titleLabel.text = @"Comments";
            detailLabel.text = @"Read all..";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleDefault;
            break;
            
        default:
            break;
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 5) {
        [self performSegueWithIdentifier:@"ratingSegue" sender:self];
    }
    if (indexPath.row == 6) {
        [self performSegueWithIdentifier:@"idSegueComments" sender:self];
    }
}

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ((indexPath.row == 5) ||(indexPath.row == 6))
    {
        return indexPath;
    }
    return nil;
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"ratingSegue"]) {
        RateViewController* controller =
        (RateViewController*)[[segue destinationViewController] topViewController];
        controller.instructor_id = self.instructor_id;
    }
    if ([segue.identifier isEqualToString:@"idSegueComments"]) {
        CommentsViewController *commentsViewController = [segue destinationViewController];
        commentsViewController.instructor_id = self.instructor_id;
    }
}
@end
