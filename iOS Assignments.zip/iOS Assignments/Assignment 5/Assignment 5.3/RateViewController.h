//
//  RateViewController.h
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/15/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RateViewController : UITableViewController

@property (nonatomic, strong) NSString *instructor_id;
@property (copy, nonatomic) NSString *rating;
@property (assign, nonatomic) NSInteger selectedIndex;
-(void)saveAction;
-(void)cancelAction;
@end
