//
//  RateViewController.m
//  Assignment 5.3
//
//  Created by Shameetha Sara Jacob on 11/15/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "RateViewController.h"

@interface RateViewController ()
@end

@implementation RateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.separatorColor = [UIColor clearColor];
    self.title = @"Rate";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelAction)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveAction)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reuseIdentifier"];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellEditingStyleNone;
    }
    UIImageView *starRating = (UIImageView *)[cell viewWithTag:100];
    starRating.image = [self imageForRating:indexPath.row];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.navigationItem.rightBarButtonItem setEnabled:YES];
    _selectedIndex = indexPath.row + 1;
    }
- (UIImage *)imageForRating:(NSInteger)rating
{
    switch (rating) {
        case 0: return [UIImage imageNamed:@"1-star-rating"];
        case 1: return [UIImage imageNamed:@"2-star-rating"];
        case 2: return [UIImage imageNamed:@"3-star-rating"];
        case 3: return [UIImage imageNamed:@"4-star-rating"];
        case 4: return [UIImage imageNamed:@"5-star-rating"];
    }
    return nil;
}

-(void)saveAction {
    if(_selectedIndex >0) {
    [self dismissViewControllerAnimated:YES completion:nil];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    NSString *URLString = [NSString stringWithFormat:@"http://bismarck.sdsu.edu/rateme/rating/%@/%ld", self.instructor_id, (long)_selectedIndex];
    NSLog(@"%ld",(long)_selectedIndex);
    NSURL *url = [NSURL URLWithString:URLString];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[[NSString stringWithFormat:@"%ld",(long)_selectedIndex] dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [connection start];
    
    if(connection)
        
        NSLog(@"Connection");
    else
        NSLog(@"No Connection");
    }
    
}

-(void)cancelAction {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


@end
