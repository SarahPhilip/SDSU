//
//  main.c
//  Assignment 1
//
//  Created by Shameetha Sara Jacob on 8/27/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#include <stdio.h>
#include <math.h>

static int num=0;

void polyTable(int N) {
    printf("k   k³ + 2*k - 3\n");
    printf("-   ------------\n");
    for (int k=1; k<=N; k++) {
        int result = (k*k*k) + 2*k - 3;
        printf("%d %5d\n",k,result);
    }
}

int runningSum(int n) {
    int sum = num + n;
    num=sum;
    return sum;
}

int fibonacci(int x) {
    if (x == 0) {
       return 0;
    }
    else if (x == 1) {
        return 1;
    }
    else {
        return (fibonacci(x - 1) + fibonacci(x - 2));
    }
}

float compute(int n) {
    float y = 1.1;
    for (int k = 0;k < n;k++)
        for (int j = 0; j < n;j++) {
            y = sin(k*j + y);
            printf("%f", y);
        }
    return y;
}

int main(int argc, const char * argv[])
{

    
    polyTable(4);
    
    int x1 = runningSum(2);
    printf("x1 = %d\n",x1);
    int x2 = runningSum(2);
    printf("x2 = %d\n",x2);
    int x3 = runningSum(3);
    printf("x3 = %d\n",x3);
    int x4 = runningSum(5);
    printf("x4 = %d\n",x4);
    
    printf("F6 is %d\n",fibonacci(6));
    
    compute(1100);
    return 0;
}

