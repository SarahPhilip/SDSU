//
//  ViewController.m
//  test2
//
//  Created by Shameetha Sara Jacob on 10/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextField *xField;
@property (weak, nonatomic) IBOutlet UITextField *yField;
@property (weak, nonatomic) IBOutlet UILabel *xCoord;
@property (weak, nonatomic) IBOutlet UILabel *yCoord;
@property (weak, nonatomic) IBOutlet UILabel *movingLabel;
@property CGPoint startPoint;
- (IBAction)update:(id)sender;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)update:(id)sender {
}
- (IBAction)textFieldDoneEditing:(id)sender {
    [self.textField resignFirstResponder];
    [self.xField resignFirstResponder];
    [self.yField resignFirstResponder];
//    UIView * firstResponder = [[self view] getFirstResponder];
//    if( [firstResponder isKindOfClass:[UITextField class]] )
//        [firstResponder resignFirstResponder];
}

- (void) touchesBegan:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    _startPoint = [theTouch locationInView:self.view];
    CGFloat x = _startPoint.x;
    CGFloat y = _startPoint.y;
    _xCoord.text = [NSString stringWithFormat:@"x = %f", x];
    _yCoord.text = [NSString stringWithFormat:@"y = %f", y];
}
- (void) touchesMoved:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    CGPoint touchLocation =
    [theTouch locationInView:self.view];
    CGFloat x = touchLocation.x;
    CGFloat y = touchLocation.y;
    _xCoord.text = [NSString stringWithFormat:@"x = %f", x];
    _yCoord.text = [NSString stringWithFormat:@"y = %f", y];
}
- (void) touchesEnded:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    CGPoint endPoint = [theTouch locationInView:self.view];
    _xCoord.text = [NSString stringWithFormat:
                    @"start = %f, %f", _startPoint.x, _startPoint.y];
    _yCoord.text = [NSString stringWithFormat:
                    @"end = %f, %f", endPoint.x, endPoint.y];
}

@end
