//
//  ViewController.m
//  test3
//
//  Created by Shameetha Sara Jacob on 10/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextField *xField;
@property (weak, nonatomic) IBOutlet UITextField *yField;
@property (weak, nonatomic) IBOutlet UILabel *movingLabel;
@property CGPoint startPoint;
- (IBAction)update:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void) hideKeyboard {
    UIView * firstResponder = [[self view] getFirstResponder];
    if( [firstResponder isKindOfClass:[UITextField class]] )
        [firstResponder resignFirstResponder];
}
-(void) saveData {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // saving an NSString
    [prefs setObject:[NSString stringWithFormat:@"%@", _textField.text] forKey:@"keyForText"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _xField.text] forKey:@"keyForX"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _yField.text] forKey:@"keyForY"];
    [prefs synchronize];
    
}
-(void) loadData {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // getting an NSString
    NSString *x = [prefs stringForKey:@"keyForX"];
    NSString *y = [prefs stringForKey:@"keyForY"];
    NSString *val = [prefs stringForKey:@"keyForText"];
    _textField.text = val;
    _xField.text = x;
    _yField.text = y;
    _movingLabel.text = val;
    _movingLabel.center = CGPointMake([x floatValue],[y floatValue]);
}
- (IBAction)update:(id)sender {
    [self hideKeyboard];
    _movingLabel.text = [NSString stringWithFormat:@"%@", _textField.text];
    if ((_xField.text && _xField.text.length > 0)&&(_yField.text && _yField.text.length > 0))
    {
        CGFloat x = [[NSString stringWithFormat:@"%@", _xField.text]floatValue];
        CGFloat y = [[NSString stringWithFormat:@"%@", _yField.text]floatValue];
        _movingLabel.center = CGPointMake(x,y);
    }
    
}
- (IBAction)textFieldDoneEditing:(id)sender {
    [self hideKeyboard];
}

- (void) touchesBegan:(NSSet *)touches
            withEvent:(UIEvent *)event {
    [self hideKeyboard];
    if (_movingLabel.text && _movingLabel.text.length > 0) {
    UITouch *theTouch = [touches anyObject];
    _startPoint = [theTouch locationInView:self.view];
    CGFloat x = _startPoint.x;
    CGFloat y = _startPoint.y;
    _xField.text = [NSString stringWithFormat:@"%.2f", x];
    _yField.text = [NSString stringWithFormat:@"%.2f", y];
    _movingLabel.center = CGPointMake(x,y);
    }
}
- (void) touchesMoved:(NSSet *)touches
            withEvent:(UIEvent *)event {
    if (_movingLabel.text && _movingLabel.text.length > 0) {
    UITouch *theTouch = [touches anyObject];
    CGPoint touchLocation =
    [theTouch locationInView:self.view];
    CGFloat x = touchLocation.x;
    CGFloat y = touchLocation.y;
    _xField.text = [NSString stringWithFormat:@"%.2f", x];
    _yField.text = [NSString stringWithFormat:@"%.2f", y];
    _movingLabel.center = CGPointMake(x,y);
    }
}

@end
