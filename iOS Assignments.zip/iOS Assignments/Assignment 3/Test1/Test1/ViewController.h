//
//  ViewController.h
//  Test1
//
//  Created by Shameetha Sara Jacob on 9/29/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)textFieldDoneEditing:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *stringField;
@property (weak, nonatomic) IBOutlet UITextField *xField;
@property (weak, nonatomic) IBOutlet UITextField *yField;
@property (weak, nonatomic) IBOutlet UILabel *movingLabel;

//- (IBAction)updateButton:(id)sender;

@end

