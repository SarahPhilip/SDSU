//
//  ViewController.m
//  Test1
//
//  Created by Shameetha Sara Jacob on 9/29/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property CGPoint startPoint;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)backgroundTap:(id)sender {
    [self.stringField resignFirstResponder];
    [self.xField resignFirstResponder];
    [self.yField resignFirstResponder];
}
- (IBAction)textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
}
- (IBAction)updateButton:(id)sender {
    NSString *title = [sender titleForState:UIControlStateNormal];
    NSString *plainText = [NSString stringWithFormat:@"%@ button pressed.", title];
    _movingLabel.text = plainText;
}
- (void) touchesBegan:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    _startPoint = [theTouch locationInView:self.view];
    CGFloat x = _startPoint.x;
    CGFloat y = _startPoint.y;
    _xField.text = [NSString stringWithFormat:@"x = %f", x];
    _yField.text = [NSString stringWithFormat:@"y = %f", y];
}
- (void) touchesMoved:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    CGPoint touchLocation =
    [theTouch locationInView:self.view];
    CGFloat x = touchLocation.x;
    CGFloat y = touchLocation.y;
    _xField.text = [NSString stringWithFormat:@"x = %f", x];
    _yField.text = [NSString stringWithFormat:@"y = %f", y];
}
@end
