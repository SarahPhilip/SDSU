//
//  ViewController.m
//  asmt3
//
//  Created by Shameetha Sara Jacob on 10/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextField *xCoord;
@property (weak, nonatomic) IBOutlet UITextField *yCoord;
@property (weak, nonatomic) IBOutlet UILabel *updateLabel;
@property CGPoint startPoint;
- (IBAction)update;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) hideKeyboard {
    UIView * firstResponder = [[self view] getFirstResponder];
    if( [firstResponder isKindOfClass:[UITextField class]] )
        [firstResponder resignFirstResponder];
}

-(void) saveData {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // saving an NSString
    [prefs setObject:[NSString stringWithFormat:@"%@", _textField.text] forKey:@"keyForText"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _xCoord.text] forKey:@"keyForX"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _yCoord.text] forKey:@"keyForY"];
    [prefs synchronize];

}

-(void) loadData {
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // getting an NSString
    NSString *x = [prefs stringForKey:@"keyForX"];
    NSString *y = [prefs stringForKey:@"keyForY"];
    NSString *val = [prefs stringForKey:@"keyForText"];
    _textField.text = val;
    _xCoord.text = x;
    _yCoord.text = y;
    _movingLabel.text = val;
    _movingLabel.center = CGPointMake([x floatValue],[y floatValue]);
}
- (IBAction)update {
    [self hideKeyboard];
    _updateLabel.text = [NSString stringWithFormat:@"%@", _textField.text];
    if ((_xCoord.text && _xCoord.text.length > 0)&&(_yCoord.text && _yCoord.text.length > 0))
    {
        CGFloat x = [[NSString stringWithFormat:@"%@", _xCoord.text]floatValue];
        CGFloat y = [[NSString stringWithFormat:@"%@", _yCoord.text]floatValue];
        _updateLabel.center = CGPointMake(x,y);
    }
    [self saveData];
}

- (IBAction)textFieldDoneEditing {
    [self hideKeyboard];
}
- (void) touchesBegan:(NSSet *)touches
            withEvent:(UIEvent *)event {
    //    [self hideKeyboard];
    UITouch *theTouch = [touches anyObject];
    _startPoint = [theTouch locationInView:self.view];
    CGFloat x = _startPoint.x;
    CGFloat y = _startPoint.y;
    //    _xCoord.text = [NSString stringWithFormat:@"x = %f", x];
    //    _yCoord.text = [NSString stringWithFormat:@"y = %f", y];
    _xCoord.text = [NSString stringWithFormat:@"%.2f", x];
    _yCoord.text = [NSString stringWithFormat:@"%.2f", y];
    _updateLabel.center = CGPointMake(x,y);
}
- (void) touchesMoved:(NSSet *)touches
            withEvent:(UIEvent *)event {
    
    UITouch *theTouch = [touches anyObject];
    CGPoint touchLocation =
    [theTouch locationInView:self.view];
    CGFloat x = touchLocation.x;
    CGFloat y = touchLocation.y;
        _xCoord.text = [NSString stringWithFormat:@"%f", x];
        _yCoord.text = [NSString stringWithFormat:@"%f", y];
    
    _updateLabel.center = CGPointMake(x,y);
}
//- (void) touchesBegan:(NSSet *)touches
//            withEvent:(UIEvent *)event {
//    if (_movingLabel.text && _movingLabel.text.length > 0) {
//    UITouch *theTouch = [touches anyObject];
//    _startPoint = [theTouch locationInView: self.view];
//    CGFloat x = _startPoint.x;
//    CGFloat y = _startPoint.y;
//    _xCoord.text = [NSString stringWithFormat:@"%f", x];
//    _yCoord.text = [NSString stringWithFormat:@"%f", y];
//    _movingLabel.center = CGPointMake(x,y);
//}
//}
@end
