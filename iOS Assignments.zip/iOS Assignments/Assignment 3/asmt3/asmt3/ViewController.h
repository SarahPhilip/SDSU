//
//  ViewController.h
//  asmt3
//
//  Created by Shameetha Sara Jacob on 10/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+getFirstResponder.h"
#import "AppDelegate.h"

@interface ViewController : UIViewController

- (IBAction)textFieldDoneEditing;

@end

