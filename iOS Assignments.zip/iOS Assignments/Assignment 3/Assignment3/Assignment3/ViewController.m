//
//  ViewController.m
//  Assignment3
//
//  Created by Shameetha Sara Jacob on 9/29/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextField *xField;
@property (weak, nonatomic) IBOutlet UITextField *yField;
@property (weak, nonatomic) IBOutlet UILabel *xCoord;
@property (weak, nonatomic) IBOutlet UILabel *yCoord;
@property CGPoint startPoint;
- (IBAction)update:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UILabel *movingLabel;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // getting an NSString
    NSString *x = [prefs stringForKey:@"keyForX"];
    NSString *y = [prefs stringForKey:@"keyForY"];
    NSString *val = [prefs stringForKey:@"keyForText"];
    _textField.text = val;
    _xField.text = x;
    _yField.text = y;
    _movingLabel.text = val;
    _movingLabel.center = CGPointMake([x floatValue],[y floatValue]);
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    [tap setCancelsTouchesInView:NO];
    [self.view addGestureRecognizer:tap];
    }

-(void)dismissKeyboard {
    UIView * firstResponder = [[self view] findFirstResponder];
    if( [firstResponder isKindOfClass:[UITextField class]] )
        [firstResponder resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)textFieldDoneEditing:(id)sender {
//    [sender resignFirstResponder];
    UIView * firstResponder = [[self view] findFirstResponder];
    if( [firstResponder isKindOfClass:[UITextField class]] )
        [firstResponder resignFirstResponder];
}
//- (IBAction)backgroundTap:(id)sender {
////    [self.textField resignFirstResponder];
////    [self.xField resignFirstResponder];
////    [self.yField resignFirstResponder];
//    UIView * firstResponder = [[self view] findFirstResponder];
//    if( [firstResponder isKindOfClass:[UITextField class]] )
//        [firstResponder resignFirstResponder];
//}

- (IBAction)update:(UIButton *)sender {
    _movingLabel.text = [NSString stringWithFormat:@"%@", _textField.text];
    if ((_xField.text && _xField.text.length > 0)&&(_yField.text && _yField.text.length > 0))
    {
        CGFloat x = [[NSString stringWithFormat:@"%@", _xField.text]floatValue];
        CGFloat y = [[NSString stringWithFormat:@"%@", _yField.text]floatValue];
        _movingLabel.center = CGPointMake(x,y);
    }
    //Close keboard on clicking update button.
    [self.view endEditing:YES];
    
    //Saving to database.
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    // saving an NSString
    [prefs setObject:[NSString stringWithFormat:@"%@", _textField.text] forKey:@"keyForText"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _xField.text] forKey:@"keyForX"];
    [prefs setObject:[NSString stringWithFormat:@"%@", _yField.text] forKey:@"keyForY"];
    [prefs synchronize];
}
- (void) touchesBegan:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    _startPoint = [theTouch locationInView:self.view];
    CGFloat x = _startPoint.x;
    CGFloat y = _startPoint.y;
    _xCoord.text = [NSString stringWithFormat:@"x = %f", x];
    _yCoord.text = [NSString stringWithFormat:@"y = %f", y];
}
- (void) touchesMoved:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    CGPoint touchLocation =
    [theTouch locationInView:self.view];
    CGFloat x = touchLocation.x;
    CGFloat y = touchLocation.y;
    _xCoord.text = [NSString stringWithFormat:@"x = %f", x];
    _yCoord.text = [NSString stringWithFormat:@"y = %f", y];
}
- (void) touchesEnded:(NSSet *)touches
            withEvent:(UIEvent *)event {
    UITouch *theTouch = [touches anyObject];
    CGPoint endPoint = [theTouch locationInView:self.view];
    _xCoord.text = [NSString stringWithFormat:
                    @"start = %f, %f", _startPoint.x, _startPoint.y];
    _yCoord.text = [NSString stringWithFormat:
                    @"end = %f, %f", endPoint.x, endPoint.y];
}
@end
