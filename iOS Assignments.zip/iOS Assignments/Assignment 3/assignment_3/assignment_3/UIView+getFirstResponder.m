//
//  UIView+getFirstResponder.m
//  assignment_3
//
//  Created by Shameetha Sara Jacob on 10/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "UIView+getFirstResponder.h"

@implementation UIView (getFirstResponder)
- (UIView *) getFirstResponder
{
    if (self.isFirstResponder) {
        return self;
    }
    for (UIView *subView in self.subviews) {
        UIView *firstResponder = [subView getFirstResponder];
        if (firstResponder != nil) {
            return firstResponder;
        }
    }
    return nil;
}

@end
