//
//  NSString+phoneFormat.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "NSString+phoneFormat.h"

@implementation NSString (phoneFormat)

-(NSString*) phoneFormat{
    static NSCharacterSet* phoneNumber = nil;
    if (phoneNumber == nil)
    {
        phoneNumber = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    }
    NSString* phoneString = [[self componentsSeparatedByCharactersInSet:phoneNumber] componentsJoinedByString:@""];
    return [NSString stringWithFormat:@"%@-%@-%@", [phoneString substringToIndex:3], [phoneString substringWithRange:NSMakeRange(3, 3)],[phoneString substringFromIndex:6]];
    
}

@end
