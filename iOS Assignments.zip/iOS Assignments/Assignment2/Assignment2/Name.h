//
//  Name.h
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/12/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Name : NSObject

@property (nonatomic) NSString * firstName;
@property (nonatomic) NSString * lastName;

+ (id) firstName: (NSString *) firstName lastName: (NSString *) lastName;
- (NSString*) description;
- (NSComparisonResult)compare:(Name *) aName;

@end
