//
//  ContactList.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/12/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "ContactList.h"

@implementation ContactList

-(id) init
{
    self = [super init];
    if (self) {
        _contactList= [[NSMutableArray alloc] init];
    }
    return self;
}


- (void) addPerson: (Person *) newContact
{
    Person *person = [Person new];
    person.firstName = newContact.firstName;
    person.lastName = newContact.lastName;
    for( PhoneNumber *phno in newContact.phoneNumber)
    {
        [person setPhoneNumber:phno];
    }
    [_contactList addObject:person];
    return;
    
}

- (NSArray *) orderedByName
{

    NSSortDescriptor *lastNameDescriptor = [[NSSortDescriptor alloc]
                                            initWithKey:@"lastName" ascending:YES selector:@selector(localizedStandardCompare:)];
    NSSortDescriptor * firstNameDescriptor = [[NSSortDescriptor alloc]
                                              initWithKey:@"firstName" ascending:YES selector:@selector(localizedStandardCompare:)];
    NSArray *sortDescriptors = @[lastNameDescriptor, firstNameDescriptor];
    NSArray *sortedArray = [_contactList sortedArrayUsingDescriptors:sortDescriptors];
    return sortedArray;
}
- (NSArray *) phoneNumberFor: (NSString *)lastName
{
    NSArray * result = [NSArray new];
    for(Person *p in _contactList)
    {
        if([p.lastName isEqualToString:lastName])
        {
            result = p.phoneNumber;
            break;
        }
    }
    return result;
    
    
}
- (NSString *) nameForNumber: (NSString *) phoneNumber
{
    for(Person * p in _contactList)
    {
        if ([p hasNumber:phoneNumber])
        {
            return p.description;
        }
    }
    return nil;


}
@end
