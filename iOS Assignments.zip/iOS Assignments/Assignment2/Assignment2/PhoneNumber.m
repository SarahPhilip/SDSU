//
//  PhoneNumber.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "PhoneNumber.h"

@implementation PhoneNumber

static NSString * const Mobile = @"Mobile";
static NSString * const Home = @"Home";
static NSString * const Work = @"Work";
static NSString * const Main = @"Main";
static NSString * const HomeFax = @"Home Fax";
static NSString * const Workfax = @"Work Fax";
static NSString * const Pager = @"Pager";
static NSString * const Other = @"Other";

+ (id) type: (NSString *) phoneType number: (NSString *) number
{
    PhoneNumber *phone = [PhoneNumber new];
    phone.type = phoneType;
    phone.number = number;
    return phone;
}

- (NSString *) number
{
    return [_number phoneFormat];
}

-(BOOL) isMobile
{
    if ([_type isEqualToString:Mobile]) {
        return YES;
    }
    else
    {
        return NO;
    }
    
}

-(BOOL) isLocal
{
    if([self.number hasPrefix:@"858"]||[self.number hasPrefix:@"619"])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

-(NSString *) description
{
    return [NSString stringWithFormat:@"%@ : %@", self.type, self.number];
}
@end
