//
//  NSString+asPhoneNumber.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/12/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "NSString+asPhoneNumber.h"

@implementation NSString (asPhoneNumber)
static int flag = 0;
-(PhoneNumber *) asPhoneNumber
{
    PhoneNumber * phone;
    NSArray *subStrings = [self componentsSeparatedByString:@":"];
    if (!subStrings) {
        flag = 1;
    }
    else
    {
        NSString * type = [subStrings objectAtIndex:0];
        NSString * number = [subStrings objectAtIndex:1];
        if ([type isEqualToString:@"Mobile"]||[type isEqualToString:@"Home"]||[type isEqualToString:@"Work"]||[type isEqualToString:@"Main"]||[type isEqualToString:@"HomeFax"]||[type isEqualToString:@"Workfax"]||[type isEqualToString:@"Pager"]||[type isEqualToString:@"Other"])
        {
            NSString *regExPattern = @"[0-9]{3}+\\-[0-9]{3}+\\-[0-9]{4}";
            NSRegularExpression *regEx = [[NSRegularExpression alloc] initWithPattern:regExPattern options:NSRegularExpressionCaseInsensitive error:nil];
            NSUInteger regExMatches = [regEx numberOfMatchesInString:number options:0 range:NSMakeRange(0, [number length])];
            if (regExMatches == 0)
            {
                flag = 1;
            }
            else
            {
                phone = [PhoneNumber new];
                phone.number = number;
                phone.type = type;
                return phone;
            }
            
        }
        else
        {
            flag = 1;
        }
    }
    @try {
        if(flag ==1)
        {
            NSException *e = [NSException
                              exceptionWithName:@"WrongFormat"
                              reason:@"Incorrect format"
                              userInfo:nil];
            @throw e;
        }
    }
    @catch (NSException *e) {
        NSLog( @"Wrong Format" );
        NSLog( @"Reason: %@", e.reason );
    }

    
}
    
@end
