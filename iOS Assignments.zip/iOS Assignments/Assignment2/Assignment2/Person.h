//
//  Person.h
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/12/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PhoneNumber.h"

@interface Person : NSObject
{
    NSMutableArray * _phoneNumber;
}

@property (nonatomic) NSString * firstName;
@property (nonatomic) NSString * lastName;


-(id)init;
+ (id) firstName: (NSString *) firstName lastName: (NSString *) lastName;

- (void)
setPhoneNumber: (PhoneNumber *) number;

- (NSString*) description;

- (NSString *) phoneNumber: (NSString *) phoneType;

- (BOOL) hasNumber: (NSString *) phoneNumber;
-(NSArray*) phoneNumber;
//- (void)addPhoneNumber: (NSMutableArray *) phoneNumber;

@end
