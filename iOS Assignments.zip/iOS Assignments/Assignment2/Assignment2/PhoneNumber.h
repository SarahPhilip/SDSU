//
//  PhoneNumber.h
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+phoneFormat.h"

@interface PhoneNumber : NSObject



@property (nonatomic) NSString *number;
@property (nonatomic) NSString *type;

+ (id) type: (NSString *) phoneType number: (NSString *) number;
- (NSString *) number;
-(BOOL) isMobile;
-(BOOL) isLocal;
-(NSString *) description;

@end
