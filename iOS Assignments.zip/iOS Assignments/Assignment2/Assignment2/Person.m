//
//  Person.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/12/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "Person.h"

@implementation Person

-(id) init
{
    self = [super init];
    if (self) {
         _phoneNumber= [[NSMutableArray alloc] init];
    }
    return self;
}

+ (id) firstName: (NSString *) firstName lastName: (NSString *) lastName
{
    Person * person = [Person new];
    person.firstName = firstName;
    person.lastName = lastName;
    return person;
}

- (void) setPhoneNumber: (PhoneNumber *) number
{
    PhoneNumber *ph = [PhoneNumber new];
    ph.type = number.type;
    ph.number = number.number;
    [_phoneNumber addObject:ph];
}

- (NSString*) description
{
    return [NSString stringWithFormat:@"%@ %@", self.firstName, self.lastName];
}

- (NSString *) phoneNumber: (NSString *) phoneType
{
    for (PhoneNumber *p in _phoneNumber) {
        if([p.type isEqualToString:phoneType])
        {
            return p.number;
        }
    }
    return nil;
}

- (BOOL) hasNumber: (NSString *) phoneNumber
{
    for (PhoneNumber *p in _phoneNumber) {
        if([[p.number phoneFormat] isEqualToString:phoneNumber])
        {
            return YES;
        }
    }
    return NO;
}

-(NSArray*) phoneNumber
{
    NSMutableArray *phoneNumber= [NSMutableArray new];
    for ( NSString *p in _phoneNumber)
    {
        [phoneNumber addObject:p];
    }
    return phoneNumber;
}

@end
