//
//  main.m
//  Assignment2
//
//  Created by Shameetha Sara Jacob on 9/11/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PhoneNumber.h"
#import "NSString+asPhoneNumber.h"
#import "Name.h"
#import "Person.h"
#import "ContactList.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
//        Question 1
        
        NSLog(@"\nFormatted string is %@",[@"6195946191" phoneFormat]);
        NSLog(@"\nFormatted string is %@",[@"619 594 6191" phoneFormat]);
        NSLog(@"\nFormatted string is %@",[@"619 5946191" phoneFormat]);
        NSLog(@"\nFormatted string is %@",[@"619-594-6191" phoneFormat]);
        
//        Question 2
        
        PhoneNumber * phone1 = [PhoneNumber type:@"Mobile" number:@"8581112233"];
        NSLog(@"ppp%@",phone1);
        PhoneNumber * phone2 = [PhoneNumber type:@"Work" number:@"6197775544"];
        PhoneNumber * phone3 = [PhoneNumber type:@"Home" number:@"9446920415"];
        NSLog(@"Phone 1 is %@ %@",phone1.type,phone1.number);
        
        if(phone1.isMobile)
        {
            NSLog(@"Phone 1 is Mobile");
        }
        else
        {
            NSLog(@"Phone 1 is not Mobile");
        }
        
        if(phone2.isMobile)
        {
            NSLog(@"Phone 2 is Mobile");
        }
        else
        {
            NSLog(@"Phone 2 is not Mobile");
        }
        
        if (phone1.isLocal) {
            NSLog(@"Phone 1 is Local");
        }
        else
        {
            NSLog(@"Phone 1 is not Local");
        }
        
        if (phone2.isLocal) {
            NSLog(@"Phone 2 is Local");
        }
        else
        {
            NSLog(@"Phone 2 is not Local");
        }
        
        if (phone3.isLocal) {
            NSLog(@"Phone 3 is Local");
        }
        else
        {
            NSLog(@"Phone 3 is not Local");
        }
        
        NSLog(@"Description %@",phone1);
        NSLog(@"Description %@",phone2);

//        Question 3
        
        NSLog(@"As Phone Number %@",[@"Work: 619-594-6191" asPhoneNumber]);
        
//        Question 4
        
        Name * name1 = [Name firstName:@"Philip" lastName:@"James"];
        Name * name2 = [Name firstName:@"Shameetha" lastName:@"Philip"];
        Name * name3 = [Name firstName:@"Philip" lastName:@"James"];
        
        NSLog(@"Description %@",name1);
        
        NSComparisonResult bar1 = [name1 compare:name2];
        NSComparisonResult bar2 = [name1 compare:name3];
        NSComparisonResult bar3 = [name2 compare:name3];
        NSLog(@"%ld",bar1);
        NSLog(@"%ld",bar2);
        NSLog(@"%ld",bar3);
        
//        Question 5
        
        Person * person1 = [Person firstName:@"Susan" lastName:@"Jacob"];
        Person * person2 = [Person firstName:@"Evana" lastName:@"Matthews"];
        Person * person3 = [Person firstName:@"Abraham" lastName:@"Jacob"];
        Person * person4 = [Person firstName:@"Philip" lastName:@"James"];
        NSArray *aa =@[person1,person2,person3];
    
        NSLog(@"Person is %@",aa);
        [person1 setFirstName:@"rrrr"];
        NSLog(@"Person is %@",aa);
        [person1 setPhoneNumber:phone1];
        [person1 setPhoneNumber:phone2];
        [person2 setPhoneNumber:phone3];
        
        NSLog(@"pppppppppppPerson is %@",person1.phoneNumber);
        NSString *p = [person1 phoneNumber:@"Mobile"];
        NSLog(@"Phone number is %@",p);
        
        NSLog(@"Has number: %hhd",[person1 hasNumber:@"8581192233"]);

//        Question 6
        ContactList * list = [ContactList new];
        [list addPerson:person1];
        [list addPerson:person2];
        [list addPerson:person3];
        [list addPerson:person4];
        [list orderedByName];
        
        NSLog(@"person1%@",list);
        NSArray *array = [list phoneNumberFor:@"Jacob"];
        NSLog(@"array:%@",array);
        
        
    }
    return 0;
}

