//
//  SDSUPhoneNumber.h
//  Assignment 2
//
//  Created by Shameetha Sara Jacob on 9/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDSUPhoneNumber : NSObject

extern NSString * const Mobile;
extern NSString * const Home;
extern NSString * const Work;
extern NSString * const Main;
extern NSString * const HomeFax;
extern NSString * const Workfax;
extern NSString * const Pager;
extern NSString * const Other;

//typedef NS_ENUM(NSUInteger, Type) {
//    Mobile,
//    Home,
//    Work,
//    Main,
//    HomeFax,
//    WorkFax,
//    Pager,
//    Other
//};
//
//extern NSString * phoneType(Type type);

@property (nonatomic) NSString *number;
@property (nonatomic) NSString *type;
@property (nonatomic, getter = isMobile) BOOL mobile;
@property (nonatomic, getter = isLocal) BOOL local;

+ (id) type: (NSString *) phoneType number: (NSString *) number;


//- (NSString *) number;
//-(BOOL) isMobile;
//-(BOOL) isLocal;
-(NSString *) description;

@end
