//
//  SDSUName.m
//  Assignment 2
//
//  Created by Shameetha Sara Jacob on 9/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "SDSUName.h"

@implementation SDSUName

//+ (id) firstName: (NSString *) firstName lastName: (NSString *) lastName
//{
//    return <#expression#>
//}
- (NSString *) description {
    return [NSString stringWithFormat:@"%@ : %@", self.firstName, self.lastName];
}
//- (NSComparisonResult)compare:(Name *) aName
//{
//    
//}

@end
