//
//  SDSUPhoneNumber.m
//  Assignment 2
//
//  Created by Shameetha Sara Jacob on 9/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "SDSUPhoneNumber.h"
#import "NSString+phoneFormat.h"

@implementation SDSUPhoneNumber

//NSString * phoneType(Type type) {
//    switch (type) {
//        case Mobile:
//            return @"Mobile";
//        case Home:
//            return @"Home";
//        case Work:
//            return @"Work";
//        case Main:
//            return @"Main";
//        case HomeFax:
//            return @"HomeFax";
//        case WorkFax:
//            return @"WorkFax";
//        case Pager:
//            return @"Pager";
//        case Other:
//            return @"Other";
//        default:
//            return nil;
//    }
//}

NSString * const Mobile = @"Mobile";
NSString * const Home = @"Home";
NSString * const Work = @"Work";
NSString * const Main = @"Main";
NSString * const HomeFax = @"Home Fax";
NSString * const Workfax = @"Work Fax";
NSString * const Pager = @"Pager";
NSString * const Other = @"Other";

+ (id) type: (NSString *) phoneType number: (NSString *) number
{
    SDSUPhoneNumber *phone = [[SDSUPhoneNumber alloc]init];
    phone.type = phoneType;
    phone.number = number;
    return phone;
}
//Getter method
- (NSString*) number {
    return [_number phoneFormat];
}

//Getter method
- (BOOL) isLocal {
    NSString * a = [self.number substringToIndex:3];
    if([a isEqualToString: @"858"]|| [a isEqualToString:@"619"])
    {
    return YES;
    }
    else
    {
        return NO;
    }
    
//    return [_number phoneFormat];
}

- (NSString *) description {
    return [NSString stringWithFormat:@"%@ : %@", self.type, self.number];
}

@end
