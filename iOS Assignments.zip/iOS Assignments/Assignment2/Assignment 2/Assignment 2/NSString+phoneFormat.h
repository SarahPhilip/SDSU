//
//  NSString+phoneFormat.h
//  Assignment 2
//
//  Created by Shameetha Sara Jacob on 9/8/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (phoneFormat)
-(NSString*) phoneFormat;

@end
