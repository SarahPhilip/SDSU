//
//  NSString+asPhoneNumber.h
//  Assignment 2
//
//  Created by Shameetha Sara Jacob on 9/10/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDSUPhoneNumber.h"


@interface NSString (asPhoneNumber)
-(SDSUPhoneNumber *) asPhoneNumber;

@end
