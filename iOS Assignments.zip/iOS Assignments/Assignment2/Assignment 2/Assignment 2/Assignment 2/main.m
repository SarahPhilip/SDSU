    //
    //  main.m
    //  Assignment 2
    //
    //  Created by Shameetha Sara Jacob on 9/8/14.
    //  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
    //

    #import <Foundation/Foundation.h>
    #import "NSString+phoneFormat.h"
    #import "NSString+asPhoneNumber.h"
    #import "SDSUPhoneNumber.h"

    int main(int argc, const char * argv[])
    {

        @autoreleasepool {
    //        
    //        NSLog(@"\n6195946191 when formateed string is %@",[@"6195946191" phoneFormat]);
    //        NSLog(@"\n619 594 6191 when formateed string is %@",[@"619 594 6191" phoneFormat]);
    //        NSLog(@"\n619 5946191 when formateed string is %@",[@"619 5946191" phoneFormat]);
    //        NSLog(@"\n619-594-6191 when formateed string is %@",[@"619-594-6191" phoneFormat]);
            
            NSLog(@"qwerty %@",[@"aa:239-234-5678" asPhoneNumber]);
//           SDSUPhoneNumber *ph = [SDSUPhoneNumber type:Mobile number:@"8789990000"];
////            SDSUPhoneNumber *ph3 =(Mobile, @"8584447777");
//            NSLog(@"abcabc%@",ph);
////            NSLog(@"qqqqqqqqqqq%@",type(WorkFax));
//            
//            SDSUPhoneNumber *phone = [SDSUPhoneNumber new];
////            phone = [@"work: 619594-6191" asPhoneNumber];
//            NSLog(@"**************Type: %@ Number: %@",phone.type, phone.number);
////            phone = [Mobile @"8584321234"];
//            
//            NSLog(@"phone new %@",phone);
//////            SDSUPhoneNumber *phone1 = [[SDSUPhoneNumber alloc]initWithType:Mobile number:@"6199990000" ];
////            
////            if(phone1.type == Mobile){
////            phone1.mobile = YES;
////                NSLog(@"yes");
////            }
////            else
////            {
////                phone1.mobile = NO;
////                NSLog(@"No");
////            }
////            
////            NSLog(@"pppp%hhd",phone1.isMobile);
////            NSLog(@"%@",phone1);
////            
////            NSLog(@"jjj%d",phone1.isLocal);
////            NSLog(@"%@",phone1);
////            
////            NSLog(@"Formatted %@",phone1.number);
////            
//        }
//        
//        
//        
        return 0;
    }

    }