//
//  AlarmObject.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlarmObject : NSObject<NSCoding>

@property(nonatomic,strong) NSString * label;
@property(nonatomic,strong) NSDate * timeToSetOff;
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic,assign) int notificationID;
//@property (nonatomic,assign) int numberOfPuzzles;


@end
