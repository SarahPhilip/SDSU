//
//  PuzzleNumberViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PuzzleNumberViewController : UITableView

@property (nonatomic, strong) NSString *instructor_id;
@property (copy, nonatomic) NSString *rating;
@property (assign, nonatomic) NSInteger selectedIndex;
-(void)saveAction;
-(void)cancelAction;
@end
