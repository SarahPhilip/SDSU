//
//  SettingsTableViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/9/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsTableViewController : UITableViewController {
    NSArray *_questions;
    NSArray *_difficulty_level;
    NSUInteger _selectedIndexNumber;
    NSUInteger _selectedIndexLevel;
}
@property (nonatomic, strong) NSString *question;
@property(nonatomic) NSInteger numeberOfPuzzles;
@property(nonatomic) NSInteger level;
- (void)refreshFields;
@end
