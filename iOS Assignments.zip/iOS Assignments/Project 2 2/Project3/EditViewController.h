//
//  EditViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

//@class EditViewController;

@protocol EditViewControllerDelegate <NSObject>
- (void)updateLabelText:(NSString*)newLabel;
@end

@interface EditViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSString * label;
@property (nonatomic, strong) UITextField *labelField;
@property(unsafe_unretained) id <EditViewControllerDelegate> delegate;

- (IBAction)doneButton:(id)sender;
@end
