//
//  AppDelegate.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AppDelegate.h"
#import "HomeViewController.h"
#import "SettingsTableViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)setupWindow
{
    UITabBarController *tabBarController = (UITabBarController *)self.window.rootViewController;
    UINavigationController *navigationController = [tabBarController viewControllers][0];
    HomeViewController *homeViewController = [navigationController viewControllers][0];
    homeViewController.alarmGoingOff = YES;
    homeViewController.numeberOfPuzzlesSolved = 0;
    [homeViewController promptForInput];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSString *question = [[NSUserDefaults standardUserDefaults] stringForKey:@"number"];
    NSString *level = [[NSUserDefaults standardUserDefaults] stringForKey:@"level"];
    NSLog(@"ques is %@ , level is %@", question, level);
    
    // Note: this will not work for boolean values as noted by bpapa below.
    // If you use booleans, you should use objectForKey above and check for null
    if(!question) {
        [self registerDefaultsFromSettingsBundle];
        question = [[NSUserDefaults standardUserDefaults] stringForKey:@"number"];
    }
    if(!level) {
        [self registerDefaultsFromSettingsBundle];
        question = [[NSUserDefaults standardUserDefaults] stringForKey:@"level"];
    }
     NSLog(@"ques after is %@ , level is %@", question, level);
//    [UIApplication sharedApplication].idleTimerDisabled = YES;
    UILocalNotification *localNotif =
    [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    
    if (localNotif)
    {
        [self setupWindow];
    }
    if ([UIApplication instancesRespondToSelector:@selector(registerUserNotificationSettings:)])
    {
        [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil]];
    }
    return YES;
    
}

- (void)registerDefaultsFromSettingsBundle {
    NSString *settingsBundle = [[NSBundle mainBundle] pathForResource:@"Settings" ofType:@"bundle"];
    if(!settingsBundle) {
        NSLog(@"Could not find Settings.bundle");
        return;
    }
    
    NSDictionary *settings = [NSDictionary dictionaryWithContentsOfFile:[settingsBundle stringByAppendingPathComponent:@"Root.plist"]];
    NSArray *preferences = [settings objectForKey:@"PreferenceSpecifiers"];
    
    NSMutableDictionary *defaultsToRegister = [[NSMutableDictionary alloc] initWithCapacity:[preferences count]];
    for(NSDictionary *prefSpecification in preferences) {
        NSString *key = [prefSpecification objectForKey:@"Key"];
        if(key && [[prefSpecification allKeys] containsObject:@"DefaultValue"]) {
            [defaultsToRegister setObject:[prefSpecification objectForKey:@"DefaultValue"] forKey:key];
        }
    }
    
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaultsToRegister];
    }
//////////
-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Best_Morning_Alarm" ofType:@"m4r"];
    
    NSURL *file = [[NSURL alloc] initFileURLWithPath:path];
    self.player =[[AVAudioPlayer alloc] initWithContentsOfURL:file error:nil];
    self.player.numberOfLoops = -1;
    self.player.currentTime = 0;
    self.player.volume = 1.0;
    [self playSound];
    [self setupWindow];
    
}

- (void) playSound{
    [self.player prepareToPlay];
    [self.player play];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    SettingsTableViewController *controller = [[SettingsTableViewController alloc]init];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    controller.numeberOfPuzzles = [[defaults objectForKey:@"number"]intValue];
    controller.level = [[defaults objectForKey:@"level"]intValue];
    [controller.tableView reloadData];
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
