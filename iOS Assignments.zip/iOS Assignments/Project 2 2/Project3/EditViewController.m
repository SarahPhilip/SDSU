//
//  EditViewController.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "EditViewController.h"

@implementation EditViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 10.0f)];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:@"cell"];
        cell.accessoryType = UITableViewCellAccessoryNone;
        
        if ([indexPath section] == 0) {
            UITextField *labelTextField = [[UITextField alloc] initWithFrame:CGRectMake(8, 4, 280, 35)];
            _labelField = labelTextField;
            labelTextField.returnKeyType = UIReturnKeyDone;
            [labelTextField becomeFirstResponder];
            labelTextField.tag = 0;
            labelTextField.delegate = self;
            labelTextField.text = _label;
            [labelTextField setEnabled: YES];
            [cell.contentView addSubview:labelTextField];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cellSelected = [tableView cellForRowAtIndexPath: indexPath];
    UITextField *textField = [[cellSelected.contentView subviews] objectAtIndex: 0];
    [textField becomeFirstResponder];
    [tableView deselectRowAtIndexPath: indexPath animated: NO];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self doneButton:nil];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (IBAction)doneButton:(id)sender {
    if([self.delegate respondsToSelector:@selector(updateLabelText:)])
    {
        [self.delegate updateLabelText:_labelField.text];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
