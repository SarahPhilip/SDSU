//
//  FoodViewController.m
//  Assignment4.1
//
//  Created by Shameetha Sara Jacob on 10/27/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "FoodViewController.h"

#define kCountry 0
#define kFood    1

@interface FoodViewController()
@property (strong, nonatomic) NSDictionary *countryFood;
@property (strong, nonatomic) NSArray *country;
@property (strong, nonatomic) NSArray *food;
@property (weak, nonatomic) IBOutlet UIPickerView *foodPicker;
@property (weak, nonatomic) IBOutlet UISlider *slider;
- (IBAction)sliderChanged:(UISlider *)sender;
@end

@implementation FoodViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSBundle *bundle = [NSBundle mainBundle];
    NSURL *plistURL = [bundle URLForResource:@"food"
                               withExtension:@"plist"];
    
    self.countryFood = [NSDictionary
                        dictionaryWithContentsOfURL:plistURL];
    
    NSArray *allCountries = [self.countryFood allKeys];
    NSArray *sortedCountries = [allCountries sortedArrayUsingSelector:@selector(compare:)];
    
    self.country = sortedCountries;
    
    NSString *selectedCountry = self.country[0];
    self.food = [self.countryFood[selectedCountry] sortedArrayUsingSelector:@selector(compare:)];
    
}

#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component {
    if (component == kCountry) {
        return [self.country count];
    } else {
        return [self.food count];
    }
}

#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    if (component == kCountry) {
        return self.country[row];
    } else {
        
        return self.food[row];
    }
}

- (void)pickerView:(UIPickerView *)pickerView
      didSelectRow:(NSInteger)row
       inComponent:(NSInteger)component
{
    if (component == kCountry) {
        NSString *selectedCountry = self.country[row];
        self.food = [self.countryFood[selectedCountry] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        [self.foodPicker reloadComponent:kFood];
        [self.foodPicker selectRow:0
                       inComponent:kFood
                          animated:YES];
        [self.slider setValue:0 animated:YES];
    }
    else {
        self.slider.maximumValue = [self.food count] - 1;
        [self.slider setValue:row animated:YES];
    }
}
- (IBAction)sliderChanged:(UISlider *)sender {
    self.slider.maximumValue = [self.food count] - 1;
    [self.foodPicker selectRow:sender.value
                   inComponent:kFood
                      animated:YES];
    [self.slider addTarget:self
                    action:@selector(sliderDidEndSliding:)
          forControlEvents:(UIControlEventTouchUpInside | UIControlEventTouchUpOutside)];
}
- (void)sliderDidEndSliding:(NSNotification *)notification {
    self.slider.maximumValue = [self.food count] - 1;
    float progress = lroundf(self.slider.value);
    [self.slider setValue:progress animated:YES];
}
@end
