//
//  SegmentViewController.h
//  Assignment4.1
//
//  Created by Shameetha Sara Jacob on 10/27/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SegmentViewController : UIViewController

@end
