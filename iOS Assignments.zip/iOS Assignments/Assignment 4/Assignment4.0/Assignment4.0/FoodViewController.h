//
//  FoodViewController.h
//  Assignment4.0
//
//  Created by Shameetha Sara Jacob on 10/23/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodViewController : UIViewController
<UIPickerViewDelegate, UIPickerViewDataSource>

@property (strong, nonatomic) NSDictionary *countryFood;
@property (strong, nonatomic) NSArray *country;
@property (strong, nonatomic) NSArray *food;
@property (weak, nonatomic) IBOutlet UIPickerView *foodPicker;
@property (weak, nonatomic) IBOutlet UISlider *slider;
- (IBAction)sliderChanged:(UISlider *)sender;
- (void)sliderDidEndSliding:(NSNotification *)notification;

@end
