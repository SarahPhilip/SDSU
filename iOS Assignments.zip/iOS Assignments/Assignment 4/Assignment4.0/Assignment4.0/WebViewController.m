//
//  WebViewController.m
//  Assignment4.0
//
//  Created by Shameetha Sara Jacob on 10/23/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
  In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
  Get the new view controller using [segue destinationViewController].
  Pass the selected object to the new view controller.
 }
 */
- (void)webViewLoad:(NSURL*)url {
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
 
}

- (IBAction)textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
    NSLog(@"%@",_textValue.text);
    NSUInteger length = [_textValue.text length];
    if (length > 0) {
        NSError *error = nil;
        NSDataDetector *dataDetector = [NSDataDetector dataDetectorWithTypes:NSTextCheckingTypeLink error:&error];
        if (dataDetector && !error) {
            NSRange range = NSMakeRange(0, length);
            NSRange notFoundRange = (NSRange){NSNotFound, 0};
            NSRange linkRange = [dataDetector rangeOfFirstMatchInString:_textValue.text options:0 range:range];
            if (!NSEqualRanges(notFoundRange, linkRange) && NSEqualRanges(range, linkRange)) {
                NSURL *url = [[NSURL alloc] initWithString:_textValue.text];
                NSLog(@"Valid");
                if ([_textValue.text hasPrefix:@"http://"]||[_textValue.text hasPrefix:@"https://"]) {
                    [self webViewLoad:url];
                }
                else {
                    NSString *httpPrefix = @"http://";
                    NSString *correctURL = [httpPrefix stringByAppendingString:_textValue.text];
                    NSURL *url = [[NSURL alloc] initWithString:correctURL];
                    [self webViewLoad:url];
                }
                
            }
            else {
                NSURL *url = [[NSURL alloc] initWithString:@"about:blank"];
                [self webViewLoad:url];
            }
    
        }
    }

}
@end
