//
//  SegmentViewController.m
//  Assignment4.0
//
//  Created by Shameetha Sara Jacob on 10/23/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "SegmentViewController.h"
@interface SegmentViewController ()

@end

@implementation SegmentViewController

- (IBAction)switchChanged:(UISwitch *)sender {
    if(sender.isOn) {
        [self.progressIndicator startAnimating];
    }
    else
        [self.progressIndicator stopAnimating];
}

- (IBAction)indexChanged:(id)sender {
    switch (self.segmentedControl.selectedSegmentIndex)
    {
        case 0:
            [self.textView resignFirstResponder];
            self.progressSwitch.hidden = NO;
            self.progressIndicator.hidden = NO;
            self.textView.hidden = YES;
            self.alertButton.hidden = YES;
            break;
        case 1:
            self.textView.hidden = NO;
            self.progressSwitch.hidden = YES;
            self.progressIndicator.hidden = YES;
            self.alertButton.hidden = YES;
            break;
        case 2:
            [self.textView resignFirstResponder];
            self.alertButton.hidden = NO;
            self.progressSwitch.hidden = YES;
            self.progressIndicator.hidden = YES;
            self.textView.hidden = YES;
            break;
        default:
            break; 
    }
}
- (IBAction)buttonPressed:(UIButton *)sender {
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Click me"
                          message:@"Do you like the iPhone"
                          delegate:self
                          cancelButtonTitle:@"Yes, I do!!!"
                          otherButtonTitles:nil];
    [alert show];
}

@end
