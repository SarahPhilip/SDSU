//
//  SegmentViewController.h
//  Assignment4.0
//
//  Created by Shameetha Sara Jacob on 10/23/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SegmentViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIButton *alertButton;
@property (weak, nonatomic) IBOutlet UISwitch *progressSwitch;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *progressIndicator;
- (IBAction)indexChanged:(id)sender;
- (IBAction)switchChanged:(UISwitch *)sender;
- (IBAction)buttonPressed:(UIButton *)sender;


@end
