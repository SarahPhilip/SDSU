//
//  AppDelegate.h
//  Assignment4.0
//
//  Created by Shameetha Sara Jacob on 10/22/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end
