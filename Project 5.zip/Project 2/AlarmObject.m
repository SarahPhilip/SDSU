//
//  AlarmObject.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AlarmObject.h"

@implementation AlarmObject
-(void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:self.label forKey:@"label"];
    [encoder encodeObject:self.timeToSetOff forKey:@"timeToSetOff"];
    [encoder encodeBool:self.enabled forKey:@"enabled"];
    [encoder encodeInt:self.notificationID forKey:@"notificationID"];
//    [encoder encodeInt:self.numberOfPuzzles forKey:@"numberOfPuzzles"];

}

-(id)initWithCoder:(NSCoder *)decoder
{
    self.label = [decoder decodeObjectForKey:@"label"];
    self.timeToSetOff = [decoder decodeObjectForKey:@"timeToSetOff"];
    self.enabled = [decoder decodeBoolForKey:@"enabled"];
    self.notificationID = [decoder decodeIntForKey:@"notificationID"];
//    self.numberOfPuzzles = [decoder decodeIntForKey:@"numberOfPuzzles"];
    return self;
}

@end
