//
//  HomeViewController.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "HomeViewController.h"
#import "AppDelegate.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self myTimerAction];
    NSRunLoop *runloop = [NSRunLoop currentRunLoop];
    NSTimer *timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(myTimerAction) userInfo:nil repeats:YES];
    [runloop addTimer:timer forMode:NSRunLoopCommonModes];
    [runloop addTimer:timer forMode:UITrackingRunLoopMode];
    [self refreshFields];
    [self createArray];
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Manage" style:UIBarButtonItemStylePlain target:self action:@selector(manageAlarms)];
//    self.navigationItem.rightBarButtonItem = rightButton;
//    self.navigationItem.title =@"Alarm";
    
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    _colon.font = [UIFont fontWithName:@"digital-7" size:90];
    _hour1.font = [UIFont fontWithName:@"digital-7" size:90];
    _hour2.font = [UIFont fontWithName:@"digital-7" size:90];
    _minute1.font = [UIFont fontWithName:@"digital-7" size:90];
    _minute2.font = [UIFont fontWithName:@"digital-7" size:90];
}

-(void)viewDidAppear:(BOOL)animated
{
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Manage" style:UIBarButtonItemStylePlain target:self action:@selector(manageAlarms)];
//    self.navigationItem.rightBarButtonItem = rightButton;
//    self.navigationItem.title =@"Alarm";
    _numeberOfPuzzlesSolved=0;
    if(self.alarmGoingOff)
    {
        [self promptForInput];
    }
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    [self refreshFields];
}

- (void)refreshFields {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _numeberOfPuzzles = [[defaults objectForKey:@"number"]intValue];
    _level = [[defaults objectForKey:@"level"]intValue];
}
//- (void)manageAlarms {
//    [self performSegueWithIdentifier:@"AddAlarm" sender:self];
//}
- (void)createArray {
    viewArrayEasy = [[NSMutableArray alloc]init];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"3 + 4 + 5 = ?"
                                                    message:nil
                                                   delegate:self
                                          cancelButtonTitle:@"Cancel"
                                          otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject: alert];
    UIAlertView *alert1 = [[UIAlertView alloc] initWithTitle:@"26 + 35 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject: alert1];
    UIAlertView *alert2 = [[UIAlertView alloc] initWithTitle:@"4 + 4 + 3 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject:alert2];
    UIAlertView *alert3 = [[UIAlertView alloc] initWithTitle:@"9 + 5 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject: alert3];
    UIAlertView *alert4 = [[UIAlertView alloc] initWithTitle:@"9 * 6 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject:alert4];
    UIAlertView *alert5 = [[UIAlertView alloc] initWithTitle:@"25 - 11"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject:alert5];
    UIAlertView *alert6 = [[UIAlertView alloc] initWithTitle:@"9 / 3 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject: alert6];
    UIAlertView *alert7 = [[UIAlertView alloc] initWithTitle:@"23 + 9 = ?"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"Cancel"
                                           otherButtonTitles:@"Continue", nil];
    [viewArrayEasy addObject:alert7];
    viewArrayMedium = [[NSMutableArray alloc]init];
    alert = [[UIAlertView alloc] initWithTitle:@"(8 * 3) + 2"
                                       message:nil
                                      delegate:self
                             cancelButtonTitle:@"Cancel"
                             otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject: alert];
    alert1 = [[UIAlertView alloc] initWithTitle:@"8 + 2 * 9"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject: alert1];
    alert2 = [[UIAlertView alloc] initWithTitle:@"30, 23, ?, 9"
                                        message:@"Find the missing number"
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject:alert2];
    alert3 = [[UIAlertView alloc] initWithTitle:@"54, ?, 74, 84"
                                        message:@"Find the missing number"
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject: alert3];
    alert4 = [[UIAlertView alloc] initWithTitle:@"28, ?, 16, 10"
                                        message:@"Find the missing number"
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject:alert4];
    alert5 = [[UIAlertView alloc] initWithTitle:@"X - 180 = 217"
                                        message:@"Find X"
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject:alert5];
    alert6 = [[UIAlertView alloc] initWithTitle:@"32 / 4 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject: alert6];
    alert7 = [[UIAlertView alloc] initWithTitle:@"86 + 39 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayMedium addObject:alert7];
    viewArrayDifficult = [[NSMutableArray alloc]init];
    alert = [[UIAlertView alloc] initWithTitle:@"23 * 5 + 8 = ?"
                                       message:nil
                                      delegate:self
                             cancelButtonTitle:@"Cancel"
                             otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject: alert];
    alert1 = [[UIAlertView alloc] initWithTitle:@"(9 * 5) + 9 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject: alert1];
    alert2 = [[UIAlertView alloc] initWithTitle:@"5 + 67 + 43 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject:alert2];
    alert3 = [[UIAlertView alloc] initWithTitle:@"54, ?, 84, 99"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject: alert3];
    alert4 = [[UIAlertView alloc] initWithTitle:@"28, ?, 18, 13"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject:alert4];
    alert5 = [[UIAlertView alloc] initWithTitle:@"X - 32 = 658"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject:alert5];
    alert6 = [[UIAlertView alloc] initWithTitle:@"520 / 8 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject: alert6];
    alert7 = [[UIAlertView alloc] initWithTitle:@"86 + 52 + 26 = ?"
                                        message:nil
                                       delegate:self
                              cancelButtonTitle:@"Cancel"
                              otherButtonTitles:@"Continue", nil];
    [viewArrayDifficult addObject:alert7];
    
}
-(void)promptForInput {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _numeberOfPuzzles = [[defaults objectForKey:@"number"]intValue];
    _level = _level = [[defaults objectForKey:@"level"]intValue];
    [self  musicStart];
//    [self createArray];
    do {
        randomNumber = arc4random_uniform(8);
    }
    while (randomNumber == previousRandomNumber);
    if (_level == 1) {
        _currentAlert = [viewArrayEasy objectAtIndex:randomNumber];
    }
    else if (_level == 2) {
        _currentAlert = [viewArrayMedium objectAtIndex:randomNumber];
    }
    else if (_level == 3) {
        _currentAlert = [viewArrayDifficult objectAtIndex:randomNumber];
    }
    [_currentAlert setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [[_currentAlert textFieldAtIndex:0] setDelegate:self];
    [[_currentAlert textFieldAtIndex:0] resignFirstResponder];
    [[_currentAlert textFieldAtIndex:0] setKeyboardType:UIKeyboardTypeNumberPad];
    [[_currentAlert textFieldAtIndex:0] becomeFirstResponder];
    [_currentAlert show];
    previousRandomNumber = randomNumber;
}
- (BOOL)alertViewShouldEnableFirstOtherButton:(UIAlertView *)alertView
{
    if ([_currentAlert.title isEqualToString:@"3 + 4 + 5 = ?"]) {
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"12"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"26 + 35 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"61"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"4 + 4 + 3 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"11"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"9 + 5 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"14"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"9 * 6 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"54"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"25 - 11"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"14"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"9 / 3 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"3"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"23 + 9 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"32"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    //////////////////
    if ([_currentAlert.title isEqualToString:@"(8 * 3) + 2"]) {
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"26"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"8 + 2 * 9"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"26"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"30, 23, ?, 9"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"16"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"54, ?, 74, 84"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"64"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"28, ?, 16, 10"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"22"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"X - 180 = 217"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"397"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"32 / 4 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"8"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"86 + 39 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"125"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    ///////////////
    if ([_currentAlert.title isEqualToString:@"(8 * 3) + 2"]) {
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"26"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"23 * 5 + 8 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"123"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"(9 * 5) + 9 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"54"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    else if ([_currentAlert.title isEqualToString:@"54, ?, 84, 99"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"69"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"28, ?, 18, 13"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"23"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"X - 32 = 658"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"690"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"520 / 8 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"65"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    else if ([_currentAlert.title isEqualToString:@"86 + 52 + 26 = ?"]) {
        
        NSString *inputText = [[_currentAlert textFieldAtIndex:0] text];
        if( [inputText isEqualToString:@"164"] )
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    
    return NO;
}
-(void)myTimerAction
{
    NSDate *date = [NSDate date];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"hh:mm a"];
    NSString *hourMinuteSecond = [dateFormatter stringFromDate:date];
    
    _hour1.text = [hourMinuteSecond substringWithRange:NSMakeRange(0, 1)];
    _hour2.text = [hourMinuteSecond substringWithRange:NSMakeRange(1, 1)];
    _minute1.text = [hourMinuteSecond substringWithRange:NSMakeRange(3, 1)];
    _minute2.text = [hourMinuteSecond substringWithRange:NSMakeRange(4, 1)];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0) {
        AppDelegate * myAppDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        [self promptForInput];
        [myAppDelegate.player play];
    }
    else {
        AppDelegate * myAppDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
        _numeberOfPuzzlesSolved++;
        if(_numeberOfPuzzlesSolved < _numeberOfPuzzles) {
            [self promptForInput];
            [myAppDelegate.player play];
        }
        else {
            [myAppDelegate.player stop];
            self.alarmGoingOff = NO;
        }
    }
}

- (void)musicStart
{
    AppDelegate * myAppDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [myAppDelegate.player play];
    
}

@end
