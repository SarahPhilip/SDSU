//
//  HomeViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UIAlertViewDelegate, UITextFieldDelegate> {
    NSInteger previousRandomNumber, randomNumber;
    NSMutableArray *viewArrayEasy, *viewArrayMedium, *viewArrayDifficult;
}

@property (weak, nonatomic) IBOutlet UILabel *hour1;
@property (weak, nonatomic) IBOutlet UILabel *hour2;
@property (weak, nonatomic) IBOutlet UILabel *colon;
@property (weak, nonatomic) IBOutlet UILabel *minute1;
@property (weak, nonatomic) IBOutlet UILabel *minute2;
@property(nonatomic) BOOL alarmGoingOff;
@property(nonatomic) NSInteger level;
@property(nonatomic) NSInteger numeberOfPuzzles;
@property(nonatomic) NSInteger numeberOfPuzzlesSolved;
@property(nonatomic) UIAlertView *currentAlert;
- (void)promptForInput;
- (void)refreshFields;
- (void)createArray;
- (void)myTimerAction;
- (void)musicStart;
@end

