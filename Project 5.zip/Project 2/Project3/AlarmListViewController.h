//
//  AlarmListViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddEditAlarmViewController.h"
#import "AlarmObject.h"



@interface AlarmListViewController : UIViewController <AddEditAlarmViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *listOfAlarms;
-(void)toggleAlarmEnabledSwitch:(id)sender;

@end
