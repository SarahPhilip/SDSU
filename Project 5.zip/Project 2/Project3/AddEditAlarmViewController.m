//
//  AddEditAlarmViewController.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AddEditAlarmViewController.h"

@implementation AddEditAlarmViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (self.editMode)
    {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSData *alarmListData = [defaults objectForKey:@"AlarmListData"];
        NSMutableArray *alarmList = [NSKeyedUnarchiver unarchiveObjectWithData:alarmListData];
        AlarmObject * oldAlarmObject = [alarmList objectAtIndex:self.indexOfAlarmToEdit];
        self.label = oldAlarmObject.label;
//        self.numberOfPuzzles = oldAlarmObject.numberOfPuzzles;
        _timeToSetOff.date = oldAlarmObject.timeToSetOff;
        self.notificationID = oldAlarmObject.notificationID;
    }
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 10.0f)];

}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.editMode)
    {
        return 2;
    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
        return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newAlarmCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"newAlarmCell"];
        cell.accessoryType = UITableViewCellAccessoryDetailButton;
        cell.selectionStyle = UITableViewCellEditingStyleNone;
    }
    if(indexPath.section == 0)
    {
        UILabel *titleLabel = (UILabel *)[cell viewWithTag:100];
        UILabel *detailLabel = (UILabel *)[cell viewWithTag:101];
        if(indexPath.row == 0)
        {
            titleLabel.text = @"Label :";
            detailLabel.text = self.label;
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    }
    if(indexPath.section == 1)
    {
        cell.backgroundColor = [UIColor whiteColor];
        cell.textLabel.textColor = [UIColor redColor];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.text = @"Delete this alarm";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        if(indexPath.row == 0)
        {
            [self performSegueWithIdentifier:@"EditSegue" sender:self];
        }
    }
    else if(indexPath.section == 1)
    {
        if(indexPath.row == 0)
        {
            UIAlertView *deleteAlarmAlert = [[UIAlertView alloc] initWithTitle:@"Delete Alarm"
                                                                       message:@"Are you sure you want to delete this alarm?"
                                                                      delegate:self
                                                             cancelButtonTitle:@"Yes"
                                                             otherButtonTitles:@"Cancel", nil];
            [deleteAlarmAlert show];
        }
    }
}

- (void)CancelExistingNotification
{
    UIApplication *app = [UIApplication sharedApplication];
    NSArray *eventArray = [app scheduledLocalNotifications];
    for (int i=0; i<[eventArray count]; i++)
    {
        UILocalNotification* oneEvent = [eventArray objectAtIndex:i];
        NSDictionary *userInfoCurrent = oneEvent.userInfo;
        NSString *uid=[NSString stringWithFormat:@"%@",[userInfoCurrent valueForKey:@"notificationID"]];
        if ([uid isEqualToString:[NSString stringWithFormat:@"%i",self.notificationID]])
        {
            [app cancelLocalNotification:oneEvent];
            break;
        }
    }
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self CancelExistingNotification];
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSData *alarmListData = [defaults objectForKey:@"AlarmListData"];
        NSMutableArray *alarmList = [NSKeyedUnarchiver unarchiveObjectWithData:alarmListData];
        [alarmList removeObjectAtIndex: self.indexOfAlarmToEdit];
        NSData *alarmListData2 = [NSKeyedArchiver archivedDataWithRootObject:alarmList];
        [[NSUserDefaults standardUserDefaults] setObject:alarmListData2 forKey:@"AlarmListData"];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
- (void)scheduleLocalNotificationWithDate:(NSDate *)fireDate
                                  atIndex:(int)indexOfObject
    {
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        if (!localNotification)
            return;
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        dateFormatter.dateFormat = @"hh-mm -a";
        NSDate* date = [dateFormatter dateFromString:[dateFormatter stringFromDate:_timeToSetOff.date]];
        localNotification.repeatInterval = NSCalendarUnitDay;
        [localNotification setFireDate:date];
        [localNotification setTimeZone:[NSTimeZone defaultTimeZone]];
        [localNotification setAlertBody:@"Alarm" ];
        [localNotification setAlertAction:@"Open App"];
        localNotification.soundName = @"Best_Morning_Alarm.m4r";
        [localNotification setHasAction:YES];
        NSNumber* uidToStore = [NSNumber numberWithInt:indexOfObject];
        NSDictionary *userInfo = [NSDictionary dictionaryWithObject:uidToStore forKey:@"notificationID"];
        localNotification.userInfo = userInfo;
        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}

-(int)getUniqueNotificationID
{
    NSMutableDictionary * uniqueDict = [[NSMutableDictionary alloc]init];
    UIApplication *app = [UIApplication sharedApplication];
    NSArray *eventArray = [app scheduledLocalNotifications];
    
    for (int i=0; i<[eventArray count]; i++)
    {
        UILocalNotification* oneEvent = [eventArray objectAtIndex:i];
        NSDictionary *userInfoCurrent = oneEvent.userInfo;
        NSNumber *uid= [userInfoCurrent valueForKey:@"notificationID"];
        NSNumber * value =[NSNumber numberWithInt:1];
        [uniqueDict setObject:value forKey:uid];
        
    }
    for (int i=0; i<[eventArray count]+1; i++)
    {
        NSNumber * value = [uniqueDict objectForKey:[NSNumber numberWithInt:i]];
        if(!value)
        {
            return i;
        }
    }
    return 0;
    
}

- (void)updateLabelText:(NSString *)newLabel
{
    self.label = newLabel;
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)cancel:(id)sender
{
    [self.delegate addEditAlarmViewControllerDidCancel:self];
}

- (IBAction)done:(id)sender
{
    AlarmObject * newAlarmObject;
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSData *alarmListData = [defaults objectForKey:@"AlarmListData"];
        NSMutableArray *alarmList = [NSKeyedUnarchiver unarchiveObjectWithData:alarmListData];
    
        if(!alarmList)
        {
            alarmList = [[NSMutableArray alloc]init];
        }
        if(self.editMode)//Editing Alarm that already exists
        {
            newAlarmObject = [alarmList objectAtIndex:self.indexOfAlarmToEdit];
    
            [self CancelExistingNotification];
        }
        else//Adding a new alarm
        {
            newAlarmObject = [[AlarmObject alloc]init];
            newAlarmObject.enabled = YES;
            newAlarmObject.notificationID = [self getUniqueNotificationID];
        }
        if(self.label)
            newAlarmObject.label = self.label;
        else
            newAlarmObject.label = @"Alarm";
//            newAlarmObject.numberOfPuzzles = _numberOfPuzzles;
            newAlarmObject.timeToSetOff = _timeToSetOff.date;
            newAlarmObject.enabled = YES;
        [self scheduleLocalNotificationWithDate:self.timeToSetOff.date atIndex:newAlarmObject.notificationID];
        if(self.editMode == NO)
        {
            [alarmList addObject:newAlarmObject];
        }
        NSData *alarmListData2 = [NSKeyedArchiver archivedDataWithRootObject:alarmList];
        [[NSUserDefaults standardUserDefaults] setObject:alarmListData2 forKey:@"AlarmListData"];
        [self.delegate addEditAlarmViewControllerDidSave:self];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"EditSegue"]) {
        EditViewController* editController = (EditViewController*)[segue destinationViewController];
        editController.delegate = self;
        editController.label = _label;
    }
}
@end
