//
//  AddEditAlarmViewController.h
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlarmObject.h"
#import "EditViewController.h"
#import <AVFoundation/AVAudioPlayer.h>

@class AddEditAlarmViewController;

@protocol AddEditAlarmViewControllerDelegate <NSObject>
- (void)addEditAlarmViewControllerDidCancel:(AddEditAlarmViewController *)controller;
- (void)addEditAlarmViewControllerDidSave:(AddEditAlarmViewController *)controller;
@end

@interface AddEditAlarmViewController : UIViewController<EditViewControllerDelegate, UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIDatePicker *timeToSetOff;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, assign) NSInteger indexOfAlarmToEdit;
@property(atomic,strong) NSString *label;
@property(nonatomic,assign) BOOL editMode;
@property(nonatomic,assign) int notificationID;
@property(nonatomic,assign) NSInteger numberOfPuzzles;
@property (nonatomic, weak) id <AddEditAlarmViewControllerDelegate> delegate;
- (IBAction)cancel:(id)sender;
- (IBAction)done:(id)sender;
- (void)CancelExistingNotification;
- (int)getUniqueNotificationID;
- (void)updateLabelText:(NSString *)newLabel;
@end
