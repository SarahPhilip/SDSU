//
//  AlarmListViewController.m
//  Project3
//
//  Created by Shameetha Sara Jacob on 12/3/14.
//  Copyright (c) 2014 Shameetha Sara Jacob(818455307). All rights reserved.
//

#import "AlarmListViewController.h"

@implementation AlarmListViewController
- (void)viewDidLoad
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *alarmListData = [defaults objectForKey:@"AlarmListData"];
    self.listOfAlarms = [NSKeyedUnarchiver unarchiveObjectWithData:alarmListData];
    [self.tableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *alarmListData = [defaults objectForKey:@"AlarmListData"];
    self.listOfAlarms = [NSKeyedUnarchiver unarchiveObjectWithData:alarmListData];
    [self.tableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.listOfAlarms){
        return [self.listOfAlarms count];
    }
    else return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self performSegueWithIdentifier:@"EditAlarm" sender:self];
    
}

- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDateFormatter * dateReader = [[NSDateFormatter alloc] init];
    [dateReader setDateFormat:@"hh:mm a"];
    AlarmObject *currentAlarm = [self.listOfAlarms objectAtIndex:indexPath.row];
    NSString *label = currentAlarm.label;
    BOOL enabled = currentAlarm.enabled;
    NSString *date = [dateReader stringFromDate:currentAlarm.timeToSetOff];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell =[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                     reuseIdentifier:CellIdentifier];
    UILabel *topLabel =[[UILabel alloc]initWithFrame:CGRectMake(15,5,168,39)];
    [cell.contentView addSubview:topLabel];
    topLabel.font = [UIFont systemFontOfSize:[UIFont labelFontSize]+2];
    UILabel *bottomLabel =[[UILabel alloc]initWithFrame:CGRectMake(15,30,168,39)];
    [cell.contentView addSubview:bottomLabel];
    UISwitch *enabledSwitch = [[UISwitch alloc]initWithFrame:CGRectMake(300,20,170,40)];
    enabledSwitch.tag = indexPath.row;
    [enabledSwitch addTarget:self
                      action:@selector(toggleAlarmEnabledSwitch:)
            forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:enabledSwitch];
    [enabledSwitch setOn:enabled];
    topLabel.text = date;
    bottomLabel.text = label;
    return cell;
}

-(void)toggleAlarmEnabledSwitch:(id)sender
{
    UISwitch *mySwitch = (UISwitch *)sender;
    if(mySwitch.isOn == NO)
    {
        UIApplication *app = [UIApplication sharedApplication];
        NSArray *alarmArray = [app scheduledLocalNotifications];
        AlarmObject *currentAlarm = [self.listOfAlarms objectAtIndex:mySwitch.tag];
        currentAlarm.enabled = NO;
        for (int i=0; i<[alarmArray count]; i++)
        {
            UILocalNotification* alarmOn = [alarmArray objectAtIndex:i];
            NSDictionary *userInfoCurrent = alarmOn.userInfo;
            NSString *uid=[NSString stringWithFormat:@"%@",[userInfoCurrent valueForKey:@"notificationID"]];
            if ([uid isEqualToString:[NSString stringWithFormat:@"%i",currentAlarm.notificationID]])
            {
                [app cancelLocalNotification:alarmOn];
                break;
            }
        }
    }
    else if(mySwitch.isOn == YES)
    {
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        AlarmObject *currentAlarm = [self.listOfAlarms objectAtIndex:mySwitch.tag];
        currentAlarm.enabled = YES;
        if (!localNotification)
            return;
        localNotification.repeatInterval = NSCalendarUnitDay;
        [localNotification setFireDate:currentAlarm.timeToSetOff];
        [localNotification setTimeZone:[NSTimeZone defaultTimeZone]];
        [localNotification setAlertBody:@"Time to wake up!!" ];
        [localNotification setAlertAction:@"Open App"];
        [localNotification setHasAction:YES];
        NSNumber* uidToStore = [NSNumber numberWithInt:currentAlarm.notificationID];
        NSDictionary *userInfo = [NSDictionary dictionaryWithObject:uidToStore forKey:@"notificationID"];
        localNotification.userInfo = userInfo;
        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    }
    NSData *alarmListData = [NSKeyedArchiver archivedDataWithRootObject:self.listOfAlarms];
    [[NSUserDefaults standardUserDefaults] setObject:alarmListData forKey:@"AlarmListData"];
}

#pragma mark - AddEditAlarmViewControllerDelegate

- (void)addEditAlarmViewControllerDidCancel:(AddEditAlarmViewController *)controller
{
    [self dismissViewControllerAnimated:YES completion:nil];

}

- (void)addEditAlarmViewControllerDidSave:(AddEditAlarmViewController *)controller
{
    [self dismissViewControllerAnimated:YES completion:nil];

}

#pragma mark - Prepare for Segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"EditAlarm"])
    {
        UINavigationController *navigationController = segue.destinationViewController;
        AddEditAlarmViewController *controller = [navigationController viewControllers][0];
        controller.indexOfAlarmToEdit = _tableView.indexPathForSelectedRow.row;
        controller.editMode = YES;
        controller.delegate = self;
    }
    if ([segue.identifier isEqualToString:@"NewAlarmSegue"]) {
        
        UINavigationController *navigationController = segue.destinationViewController;
        AddEditAlarmViewController *addEditAlarmViewController = [navigationController viewControllers][0];
        addEditAlarmViewController.editMode = NO;
        addEditAlarmViewController.delegate = self;
    }
}

@end
